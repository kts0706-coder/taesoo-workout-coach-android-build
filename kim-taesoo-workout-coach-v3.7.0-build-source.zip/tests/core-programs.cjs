// v3.7 replaces forced daily core templates with independently chosen PDF programs.
// Preserve the existing test entry point for callers.
require('./pdf-programs.cjs');
