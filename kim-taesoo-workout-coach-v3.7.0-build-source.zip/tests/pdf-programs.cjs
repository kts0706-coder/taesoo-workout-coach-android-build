// Regression coverage for freely selected PDF sessions and historical records.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const assets = path.join(__dirname, '../android-app/app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)];
const sources = scripts.map(([, attrs, inline], i) => {
  const source = attrs.match(/\bsrc="([^"]+)"/)?.[1];
  return {name: source || `inline-${i}.js`, code: source ? fs.readFileSync(path.join(assets, source), 'utf8') : inline};
});
sources.forEach(s => new vm.Script(s.code, {filename: s.name}));
assert.deepEqual(sources.filter(s => !s.name.startsWith('inline-')).map(s => s.name),
  ['program-v370.js', 'program-photos-v370.js', 'program-adapter-v370.js'],
  'Offline data, photo map and adapter must load in dependency order');
const storage = Object.create(null);
Object.defineProperties(storage, {
  getItem: {value: key => storage[key] ?? null},
  setItem: {value: (key, value) => { storage[key] = String(value); }},
  removeItem: {value: key => { delete storage[key]; }}
});
const context = vm.createContext({
  assert, console, localStorage: storage,
  document: {querySelector: () => ({})},
  photoExists: relative => fs.existsSync(path.join(assets, relative))
});
vm.runInContext('window=globalThis; let allowConfirm=true; confirm=()=>allowConfirm;', context);
for (const s of sources) {
  if (s.code.trimStart().startsWith("document.querySelectorAll('.view-btn')")) continue;
  vm.runInContext(s.code, context, {filename: s.name});
}
vm.runInContext(`
let testDate='2026-09-23';selectedDate=()=>testDate;day=2;render=()=>{};show=()=>{};
const clean=()=>Object.keys(localStorage).forEach(k=>localStorage.removeItem(k));
const seed=r=>{clean();localStorage.setItem(journalKey(testDate),JSON.stringify({date:testDate,day:2,run:{},...r}));};
const names=p=>p.ex.map(e=>e[0]);
const equalJson=(a,b,message)=>assert.equal(JSON.stringify(a),JSON.stringify(b),message);
const field=(i,n,k,value)=>saveSetInput({dataset:{setEx:String(i),setN:String(n),setK:k},value:String(value)},false);

// Exact changed movements/doses from the document, independent of weekdays.
assert.equal(Object.values(program370.strength).flat().length,6);
equalJson(names(program370.strength.back[1]),['어시스트 풀업','원암 덤벨 로우','스트레이트암 풀다운','케이블 페이스풀','케이블 컬']);
assert.equal(program370.strength.back[0].ex.at(-1)[0],'해머 컬');
assert.equal(program370.strength.back[0].ex.at(-1)[1],'2세트 × 12–15회');
assert.equal(program370.strength.legs[0].ex[2][1],'2세트 × 좌우 각 10회');
assert.ok(names(program370.strength.legs[0]).includes('시티드 카프 레이즈'));
assert.ok(names(program370.strength.legs[1]).includes('스탠딩 카프 레이즈'));
assert.ok(!names(program370.strength.legs[1]).includes('덤벨 숄더 프레스'));
assert.equal(program370.strength.legs[1].ex.at(-1)[1],'2세트 × 30m');
assert.ok(names(program370.strength.chest[1]).includes('케이블 사이드 레터럴 레이즈'));
assert.equal(program370.strength.chest[1].ex.at(-1)[0],'푸시업');
equalJson(names(program370.abs.A),['케이블 크런치','행잉 니레이즈','사이드 플랭크']);
equalJson(names(program370.abs.B),['중량 슬로우 크런치','리버스 크런치','팔로프 프레스']);
equalJson(names(program370.abs.C),['케이블 크런치','앱 롤아웃 무릎','케이블 우드찹']);
const newPlans=Object.values(program370.strength).flat().concat(Object.values(program370.abs),Object.values(program370.home));
for(const p of newPlans){
  assert.equal(new Set(names(p)).size,p.ex.length,p.title+' duplicates an exercise');
  assert.ok(!names(p).some(n=>/버드독|데드버그/.test(n)),p.title+' reintroduced a retired movement');
  for(const e of p.ex){
    const detail=program370.details[e[0]];
    assert.equal(detail.steps.length,4,e[0]+' needs 4 instructions');
    assert.ok(detail.breathing,e[0]+' needs breathing instructions');
    const target=exerciseTargetHtml(e[0]);
    assert.ok(target.includes('주요 부위')&&target.includes('집중 타깃'),e[0]+' needs target labels');
    assert.ok(!target.includes('undefined'),e[0]+' target is undefined');
  }
}
assert.ok(names(program370.home.core).includes('누워서 힐 슬라이드'));
assert.ok(names(program370.home.core).includes('베어 플랭크'));
for(const p of Object.values(program370.home))assert.ok(!names(p).some(n=>/스텝잭|마운틴 클라이머|니 드라이브|푸시업|크런치/.test(n)),'Home should emphasize recovery/stability');
for(let d=0;d<7;d++)for(const [split,variants] of Object.entries(program370.strength))for(let v=0;v<2;v++){
  const p=composedPlan370({day:d,selectedActivity:'strength',selectedSplit:split,splitVariant:v,absVariant:'none'});
  equalJson(names(p),names(variants[v]),'weekday must not choose or alter the session');
  for(const abs of ['A','B','C']){
    const combined=composedPlan370({day:d,selectedActivity:'strength',selectedSplit:split,splitVariant:v,absVariant:abs});
    equalJson(names(combined),names(variants[v]).concat(names(program370.abs[abs])),'all abs choices attach to all strength sessions');
  }
}

// First write uses v3.7 names, while historical missing snapshots keep old names.
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,exercises:[]});
assert.equal(getRecord().programVersion,370);
assert.equal(getRecord().absVariant,'none');
field(0,0,'weight',12);
assert.equal(getRecord().planExercises.length,5,'new first write snapshots strength without forced abs');
assert.equal(getRecord().planExercises[0][0],'인클라인 덤벨 프레스');
for(const version of [1,2])for(const activity of ['strength','home']){
  const base={selectedActivity:activity,selectedSplit:'chest',splitVariant:0,exercises:[{weight:'12',reps:'10'}]};
  if(version===2)base.corePlanVersion=2;
  seed(base);
  assert.notEqual(getRecord().programVersion,370,'legacy row data must block automatic template upgrade');
  const expected=activity==='home'?(version===2?v360Home:legacyHomePlan):(version===2?v360Splits.chest[0]:legacySplits.chest[0]);
  equalJson(names(recordPlan(getRecord())),names(expected),'historical names without snapshot');
  saveRecord(getRecord());
  equalJson(getRecord().planExercises,expected.ex,'historical first save freezes original names');
  chooseActivity('running');chooseActivity(activity);
  equalJson(names(recordPlan(getRecord())),names(expected),'legacy slot round trip');
  assert.equal(getRecord().exercises[0].weight,'12');
}
const explicit=[['기록 당시 전용 운동','2세트 × 11회','1_1.jpg','보존된 방법',['보존된 설명']]];
seed({programVersion:370,corePlanVersion:2,selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,
  exercises:[{done:true,sets:[{weight:'9',reps:'11'}]}],planExercises:explicit,planMeta:{title:'기록 당시 구성'}});
saveRecord(getRecord());chooseActivity('cycling');chooseActivity('strength');
equalJson(getRecord().planExercises,explicit,'explicit saved identities always win');
assert.equal(getRecord().exercises[0].sets[0].weight,'9');
seed({selectedActivity:'cycling',programVersion:370,corePlanVersion:2,exercises:[],activityRecords:{
  home:{exercises:[{done:true}],primaryActivity:{}}
}});
let archived=workoutRecords(getRecord()).find(r=>selectedActivity(r)==='home');
assert.notEqual(archived.programVersion,370,'inactive v1 slot cannot inherit current program version');
equalJson(names(recordPlan(archived)),names(legacyHomePlan));
chooseActivity('home');
assert.notEqual(getRecord().programVersion,370);
equalJson(names(recordPlan(getRecord())),names(legacyHomePlan));

// Abs selection is independent: strength rows and all performed abs survive.
seed({programVersion:370,corePlanVersion:2,selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,absVariant:'none',exercises:[]});
field(0,0,'weight',20);field(0,0,'reps',10);
let r=getRecord();r.exercises[0].done=true;saveRecord(r);
const strengthRow=JSON.stringify(getRecord().exercises[0]);
chooseAbs370('A');field(5,0,'weight',15);field(5,0,'reps',12);
r=getRecord();r.exercises[5].done=true;saveRecord(r);
chooseAbs370('B');
assert.equal(JSON.stringify(getRecord().exercises[0]),strengthRow,'switching abs preserves strength');
assert.equal(getRecord().exercises[5]?.sets?.[0]?.weight,undefined,'B cannot inherit cable crunch sets');
field(5,0,'weight',5);field(5,0,'reps',14);
r=getRecord();r.exercises[5].done=true;saveRecord(r);
chooseAbs370('none');
assert.equal(JSON.stringify(getRecord().exercises[0]),strengthRow);
assert.equal(recordValues(getRecord()).manualStrength,3,'archived A/B plus strength each counted once');
assert.ok(detailForDate(testDate).includes('케이블 크런치'));
assert.ok(detailForDate(testDate).includes('중량 슬로우 크런치'));
chooseAbs370('A');
assert.equal(getRecord().exercises[5].sets[0].weight,'15','returning to A restores its own sets');
assert.equal(recordValues(getRecord()).manualStrength,3,'active abs must not also count its archived copy');
chooseActivity('running');chooseActivity('strength');
assert.equal(getRecord().absVariant,'A');
assert.equal(getRecord().exercises[5].sets[0].weight,'15');
assert.equal(recordValues(getRecord()).manualStrength,3);
// Restoring stored abs into an otherwise short base array must preserve indices.
seed({programVersion:370,corePlanVersion:2,selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,absVariant:'none',
  exercises:[{sets:[{weight:'20'}]}],absVariantRecords:{A:{programVersion:370,corePlanVersion:2,absVariant:'A',selectedSplit:null,
    exercises:[{done:true,sets:[{weight:'15'}]}],planExercises:program370.abs.A.ex,planMeta:{title:'복근 A'}}}});
chooseAbs370('A');
assert.equal(getRecord().exercises[5]?.sets?.[0]?.weight,'15','abs row must be padded to after all 5 strength rows');
assert.equal(getRecord().exercises[1]?.done,undefined,'abs cannot become a chest press completion');

// A/B changes require the existing confirmation when rows have data.
allowConfirm=false;chooseVariant(1);
assert.equal(getRecord().splitVariant,0,'cancelled A/B change preserves old session');
assert.equal(getRecord().exercises[0].sets[0].weight,'20');
allowConfirm=true;chooseVariant(1);
assert.equal(getRecord().splitVariant,1);
assert.equal(getRecord().exercises.length,0,'confirmed A/B change must not apply old indices to new movements');
assert.equal(recordPlan(getRecord()).ex[1][0],'덤벨 숄더 프레스');

// Recovery and core Home have their own records and remain distinct in history.
seed({programVersion:370,corePlanVersion:2,selectedActivity:'home',homeVariant:'recovery',exercises:[]});
field(0,0,'reps',10);r=getRecord();r.exercises[0].done=true;saveRecord(r);
chooseHome370('core');assert.equal(getRecord().exercises.length,0);
field(3,0,'seconds',18);r=getRecord();r.exercises[3].done=true;saveRecord(r);
chooseHome370('recovery');
assert.equal(getRecord().exercises[0].sets[0].reps,'10');
assert.equal(getRecord().exercises[3]?.done,undefined);
chooseActivity('strength');chooseActivity('home');chooseHome370('core');
assert.equal(getRecord().exercises[3].sets[0].seconds,'18');
assert.equal(recordValues(getRecord()).home,2,'Home variants counted once each');
assert.ok(detailForDate(testDate).includes('베어 플랭크'));
assert.ok(detailForDate(testDate).includes('18초'));
assert.ok(detailForDate(testDate).includes('캣카우'));

// The all-program overview can select strength while another activity is open.
setStrengthChoice(getRecord(),'back',1);
assert.equal(getRecord().selectedActivity,'strength');
assert.equal(recordValues(getRecord()).home,2,'overview strength selection must preserve both Home variants');
chooseActivity('home');
assert.equal(getRecord().homeVariant,'core');
assert.equal(getRecord().exercises[3].sets[0].seconds,'18');
seed({programVersion:370,corePlanVersion:2,selectedActivity:'running',exercises:[],
  primaryActivity:{type:'running',label:'러닝',distance:'3.2',minutes:'28',done:true}});
setStrengthChoice(getRecord(),'legs',0);
assert.equal(getRecord().primaryActivity?.done,undefined,'cardio data cannot become a strength activity');
assert.equal(recordValues(getRecord()).km,3.2,'overview selection preserves the run in its own slot');
assert.equal(workoutRecords(getRecord()).filter(x=>x.primaryActivity?.done).length,1,'completed cardio is not duplicated');
// The overview checks saved strength even when another empty activity is open.
seed({programVersion:370,corePlanVersion:2,selectedActivity:'cycling',exercises:[],activityRecords:{
  strength:{selectedSplit:'chest',splitVariant:0,exercises:[{done:true,weight:'8',reps:'10'}]}
}});
const beforeCancel=localStorage.getItem(journalKey(testDate));
octoberPlanOpen=true;allowConfirm=false;
assert.equal(chooseOverviewStrength370('back',1),false);
assert.equal(localStorage.getItem(journalKey(testDate)),beforeCancel,'cancel leaves every stored slot untouched');
assert.equal(octoberPlanOpen,true,'cancel keeps the overview open');
assert.equal(chooseOverviewStrength370('chest',0),true,'same saved strength resumes without destructive confirmation');
assert.equal(getRecord().exercises[0].weight,'8');
assert.notEqual(getRecord().programVersion,370,'overview restore cannot upgrade legacy saved strength');
equalJson(names(recordPlan(getRecord())),names(legacySplits.chest[0]));
allowConfirm=true;

// No existing extra-strength row is renamed by the new free-choice templates.
for(const version of [1,2,3]){
  const rec={date:testDate,day:2,extraTemplate:1,extraCoreVersion:version};
  const expected=(version===3?planFor:version===2?v360PlanFor:legacyPlanFor)(testDate,1);
  equalJson(names(extraPlanFor(rec)),names(expected));
}
equalJson(extraPlanFor({date:testDate,extraTemplate:2,extraCoreVersion:3,extraPlanExercises:explicit}).ex,explicit);

// Timed, left/right, distance and assistance fields round-trip with their units.
assert.ok(setText({sets:[{seconds:'18'}]}).includes('18초'));
assert.ok(setText({sets:[{secondsLeft:'30',secondsRight:'28'}]}).includes('왼쪽 30초 · 오른쪽 28초'));
assert.ok(setText({sets:[{weight:'15',meters:'30'}]}).includes('15kg · 30m'));
assert.ok(hasExerciseData({exercises:[{sets:[{seconds:'18'}]}]}));
assert.ok(hasExerciseData({exercises:[{sets:[{meters:'30'}]}]}));
const lookup=name=>newPlans.flatMap(p=>p.ex).find(e=>e[0]===name);
assert.ok(setInputs({},0,false,lookup('어시스트 풀업')).includes('보조중량 kg'));
assert.ok(weightAdvice(lookup('어시스트 풀업'),null).includes('보조중량을 한 단계 줄이세요'));
assert.ok(setInputs({},0,false,lookup('베어 플랭크')).includes('data-set-k="seconds"'));
assert.ok(setInputs({},0,false,lookup('사이드 플랭크')).includes('data-set-k="secondsLeft"'));
assert.ok(setInputs({},0,false,lookup('파머스 캐리')).includes('data-set-k="meters"'));
for(const p of newPlans)for(const e of p.ex){
  const form=setInputs({},0,false,e),expected=Number(e[1].match(/^(\\d+)세트/)[1]);
  assert.equal(new Set([...form.matchAll(/data-set-n="(\\d+)"/g)].map(m=>m[1])).size,expected,e[0]+' set count must follow this session');
}
const priorDate='2026-09-22';
localStorage.setItem(journalKey(priorDate),JSON.stringify({date:priorDate,day:1,programVersion:370,selectedActivity:'home',homeVariant:'core',exercises:[null,null,null,{sets:[{seconds:'17'}]}],planExercises:program370.home.core.ex}));
assert.equal(previousExerciseRecord('베어 플랭크').data.sets[0].seconds,'17');

// Every plan reaches all 4 photos and binds the same pinch-zoom viewer.
for(const e of new Map(newPlans.flatMap(p=>p.ex).map(e=>[e[0],e])).values()){
  const markup=exerciseDetail(e,{},0),base=e[2].replace(/\\.jpg$/i,'');
  assert.equal((markup.match(/data-photo-index=/g)||[]).length,4,e[0]+' needs 4 tappable photos');
  for(let n=0;n<4;n++){
    assert.ok(exercisePhotoMarkup(e[2],e[0],n,true).includes('data-zoom-photo'),e[0]+' needs pinch binding');
    const relative=exercisePhotoBoards[base]?'images4/'+base+'.png':'images4_steps/'+base+'_'+n+'.jpg';
    assert.ok(photoExists(relative),'Missing offline photo: '+relative);
  }
}
`, context, {filename:'pdf-program-regressions.js'});
console.log('PASS: PDF selections, old/snapshotted records, abs and Home slot isolation, units, A/B changes and offline photo routes');
