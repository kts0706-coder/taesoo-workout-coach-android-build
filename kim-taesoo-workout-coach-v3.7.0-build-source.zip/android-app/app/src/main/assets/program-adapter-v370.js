// PDF program upgrade. Keep saved exercise identities independent of templates.
const program370 = window.program370;
const copy370 = value => JSON.parse(JSON.stringify(value));
const v360Splits = copy370(splitPrograms);
const v360Home = copy370(homeWorkoutPlan);
const v360PlanFor = planFor;
const baseRender370 = render;
const baseExerciseDetail370 = exerciseDetail;
const baseSetInputs370 = setInputs;
const baseWeightAdvice370 = weightAdvice;
const baseSnapshot370 = activitySnapshot;
const splitKeys370 = [['chest',0],['chest',1],['back',0],['back',1],['legs',0],['legs',1]];
Object.assign(splitPrograms, copy370(program370.strength));
Object.assign(homeWorkoutPlan, copy370(program370.home.recovery));
activityInfo.home.hint = '회복 · 코어 선택';
Object.entries(program370.details).forEach(([name,detail]) => {
  homeTargets[name] = detail.targets;
});
Object.values(program370.strength).flat().concat(Object.values(program370.abs),Object.values(program370.home)).forEach(p => p.ex.forEach(e => {
  const detail=program370.details[e[0]];
  if(detail?.steps)absSteps[e[2].replace(/\.jpg$/i,'')]=detail.steps;
}));
if(window.program370Photos)Object.assign(exercisePhotoBoards,window.program370Photos);

function composedPlan370(r) {
  const d=Number.isInteger(r.day)?r.day:day;
  if(selectedActivity(r)==='home')return {...copy370(program370.home[r.homeVariant==='core'?'core':'recovery']),d:plans[d].d,place:'집',run:null};
  const base=splitPrograms[r.selectedSplit]?.[Number(r.splitVariant||0)%2];
  if(!base)return {...plans[d],title:'오늘 할 근력운동을 선택하세요',meta:'부위와 A/B를 자유롭게 선택',ex:[]};
  const abs=program370.abs[r.absVariant];
  return {...copy370(base),d:plans[d].d,place:plans[d].place,run:null,
    title:base.title+(abs?' · 복근 '+r.absVariant:''),
    meta:'준비 5분 · '+base.meta.replace(' · 복근 별도 선택','')+(abs?' · 복근 약 12–18분':''),
    ex:[...copy370(base.ex),...(abs?copy370(abs.ex):[])]};
}
planFor=(date,index)=>{
  const pair=splitKeys370[index];
  return pair?{...copy370(splitPrograms[pair[0]][pair[1]]),d:plans[index].d,run:null}:{...plans[index%7],ex:[],run:null};
};
function extraPlanFor(r) {
  if(r?.extraPlanExercises)return {...plans[Number(r.extraTemplate)||0],ex:r.extraPlanExercises};
  const f=r?.extraCoreVersion===3?planFor:r?.extraCoreVersion===2?v360PlanFor:legacyPlanFor;
  return f(r.date,r.extraTemplate);
}
hasExerciseData=r=>(r?.exercises||[]).some(x=>x?.done||x?.weight||x?.reps||x?.sets?.some(s=>s.weight||s.reps||s.seconds||s.secondsLeft||s.secondsRight||s.meters||s.rir));
getRecord=(date=selectedDate())=>{
  const r=originalGetRecord(date);
  if(!hasExerciseData(r)){
    r.programVersion=370;r.corePlanVersion=2;
    r.absVariant=program370.abs[r.absVariant]?r.absVariant:'none';
    r.homeVariant=r.homeVariant==='core'?'core':'recovery';
    r.planExercises=null;r.planMeta=null;
  }
  return r;
};
recordPlan=r=>{
  const d=Number.isInteger(r?.day)?r.day:0;
  if(r?.planExercises?.length)return {...plans[d],...r.planMeta,d:plans[d].d,ex:r.planExercises};
  if(r?.programVersion===370)return composedPlan370(r);
  const modern=r?.corePlanVersion===2;
  if(selectedActivity(r||{})==='home')return {...(modern?v360Home:legacyHomePlan),d:plans[d].d,place:'집'};
  if(r?.selectedSplit)return {...(modern?v360Splits:legacySplits)[r.selectedSplit][Number(r.splitVariant||0)%2],d:plans[d].d};
  return (modern?v360PlanFor:legacyPlanFor)(r?.date||selectedDate(),d);
};
displayPlanFor=(date,weekday)=>{
  const r=getRecord(date),activity=selectedActivity(r);
  if(!['strength','home'].includes(activity))return {...plans[weekday],title:'오늘 할 운동을 선택하세요',meta:'원하는 운동 종류를 직접 선택',ex:[]};
  return hasExerciseData(r)?recordPlan(r):composedPlan370(r);
};
saveRecord=r=>{
  if(hasExerciseData(r)&&!r.planExercises?.length){const p=recordPlan(r);r.planExercises=copy370(p.ex);r.planMeta={title:p.title,meta:p.meta,place:p.place};}
  originalSaveRecord(r);
};
function simpleSnapshot370(r) {
  return {...baseSnapshot370(r),programVersion:r.programVersion||0,absVariant:r.absVariant||'none',homeVariant:r.homeVariant||'legacy'};
}
activitySnapshot=r=>({...simpleSnapshot370(r),homeVariantRecords:copy370(r.homeVariantRecords||{}),absVariantRecords:copy370(r.absVariantRecords||{})});
workoutRecords=r=>{
  const current=selectedActivity(r);
  const entries=[...Object.entries(r.activityRecords||{}).filter(([key])=>key!==current).map(([key,value])=>({...r,...value,selectedActivity:key,corePlanVersion:value.corePlanVersion||1,programVersion:value.programVersion||0,absVariant:value.absVariant||'none',homeVariant:value.homeVariant||'legacy',homeVariantRecords:value.homeVariantRecords||{},absVariantRecords:value.absVariantRecords||{},planExercises:value.planExercises||null,planMeta:value.planMeta||null})),r];
  return entries.flatMap(entry=>{
    const variants=selectedActivity(entry)==='home'?Object.entries(entry.homeVariantRecords||{}).filter(([key])=>key!==entry.homeVariant).map(([,x])=>({...entry,...x,selectedActivity:'home',homeVariantRecords:{},absVariantRecords:{}})):[];
    const abs=selectedActivity(entry)==='strength'?Object.entries(entry.absVariantRecords||{}).filter(([key])=>key!==entry.absVariant).map(([,x])=>({...entry,...x,selectedActivity:'strength',homeVariantRecords:{},absVariantRecords:{}})):[];
    return [...variants,...abs,entry];
  });
};
chooseActivity=activity=>{
  const r=getRecord(),old=selectedActivity(r);if(old===activity||!activityInfo[activity])return;
  r.activityRecords=r.activityRecords||{};if(old)r.activityRecords[old]=activitySnapshot(r);
  const saved=r.activityRecords[activity]||{exercises:[],primaryActivity:{},assignedPlan:null,selectedSplit:r.selectedSplit,splitVariant:r.splitVariant,programVersion:370,corePlanVersion:2,absVariant:'none',homeVariant:'recovery'};
  Object.assign(r,{planExercises:null,planMeta:null,programVersion:0,absVariant:'none',homeVariant:'legacy',homeVariantRecords:{},absVariantRecords:{}},copy370(saved),{selectedActivity:activity,corePlanVersion:saved.corePlanVersion||1});
  saveRecord(r);focus=0;expandedExercise=null;show(`${activityInfo[activity].label}을 선택했습니다`);render();
};
function strengthHasData370(r) {
  return hasExerciseData(r)||Object.values(r?.absVariantRecords||{}).some(hasExerciseData);
}
function sameStrengthChoice370(r,split,variant) {
  return r?.selectedSplit===split&&Number(r.splitVariant||0)===variant;
}
setStrengthChoice=(r,split,variant)=>{
  if(!splitPrograms[split]?.[variant])return;
  const old=selectedActivity(r),saved=old==='strength'?activitySnapshot(r):r.activityRecords?.strength;
  const restore=saved&&sameStrengthChoice370(saved,split,variant)&&strengthHasData370(saved);
  r.activityRecords=r.activityRecords||{};
  if(old&&old!=='strength')r.activityRecords[old]=activitySnapshot(r);
  // A direct choice from the overview must keep the activity currently open.
  // Selecting an already recorded strength choice resumes its own saved rows.
  Object.assign(r,{primaryActivity:{},assignedPlan:null,planExercises:null,planMeta:null,
    programVersion:370,corePlanVersion:2,absVariant:'none',absVariantRecords:{},
    homeVariant:'recovery',homeVariantRecords:{}});
  if(restore)Object.assign(r,copy370(saved),{selectedActivity:'strength',programVersion:saved.programVersion||0,corePlanVersion:saved.corePlanVersion||1});
  else{
    Object.assign(r,{selectedActivity:'strength',selectedSplit:split,splitVariant:variant,exercises:[]});
    const p=composedPlan370(r);r.assignedPlan={sourceDate:r.date,sourceDay:day,category:splitInfo[split].label,title:p.title,total:p.ex.length};
  }
  saveRecord(r);focus=0;expandedExercise=null;show(`${splitInfo[split].label} ${variant?'B':'A'} 운동을 선택했습니다`);render();
};
function chooseOverviewStrength370(split,variant) {
  const r=getRecord(),saved=selectedActivity(r)==='strength'?r:r.activityRecords?.strength;
  if(strengthHasData370(saved)&&!sameStrengthChoice370(saved,split,variant)&&
    !confirm('오늘 입력한 근력 기록을 초기화하고 선택한 구성으로 바꿀까요?'))return false;
  octoberPlanOpen=false;setStrengthChoice(r,split,variant);return true;
}
function chooseAbs370(variant) {
  const r=getRecord();if(r.programVersion!==370||r.absVariant===variant||!r.selectedSplit)return;
  const old=recordPlan(r),baseCount=splitPrograms[r.selectedSplit][Number(r.splitVariant||0)%2].ex.length;
  r.absVariantRecords=r.absVariantRecords||{};
  if(program370.abs[r.absVariant])r.absVariantRecords[r.absVariant]={programVersion:370,corePlanVersion:2,absVariant:r.absVariant,selectedSplit:null,exercises:copy370((r.exercises||[]).slice(baseCount)),planExercises:copy370(old.ex.slice(baseCount)),planMeta:{title:'복근 '+r.absVariant,meta:'복근 기록'}};
  const saved=r.absVariantRecords[variant];
  r.exercises=[...Array.from({length:baseCount},(_,i)=>r.exercises?.[i]||{}),...copy370(saved?.exercises||[])];
  r.absVariant=variant;r.planExercises=null;r.planMeta=null;
  const p=composedPlan370(r);r.planExercises=copy370(p.ex);r.planMeta={title:p.title,meta:p.meta,place:p.place};
  r.assignedPlan={sourceDate:r.date,sourceDay:day,category:splitInfo[r.selectedSplit].label,title:p.title,total:p.ex.length};
  saveRecord(r);focus=0;expandedExercise=null;render();show(variant==='none'?'오늘 복근은 쉬기로 했습니다':`복근 ${variant}를 선택했습니다`);
}
function chooseHome370(variant) {
  const r=getRecord();if(r.programVersion===370&&r.homeVariant===variant)return;
  const records=r.homeVariantRecords||{},old=r.programVersion===370?r.homeVariant:'legacy';
  if(hasExerciseData(r))records[old]=simpleSnapshot370(r);
  const saved=records[variant]||{programVersion:370,corePlanVersion:2,exercises:[],primaryActivity:{},assignedPlan:null,homeVariant:variant,absVariant:'none',planExercises:null,planMeta:null};
  Object.assign(r,copy370(saved),{selectedActivity:'home',homeVariant:variant,homeVariantRecords:records,absVariantRecords:{}});
  saveRecord(r);focus=0;expandedExercise=null;render();show(`${variant==='core'?'코어':'회복'} 홈트를 선택했습니다`);
}
renderSplitPicker=r=>{
  $('#splitOptions').innerHTML=Object.entries(splitInfo).map(([key,x])=>`<button class="split-choice ${r.selectedSplit===key?'active':''}" data-split="${key}"><span>${x.label}</span><small>${x.sub}<br>준비운동 5분</small></button>`).join('');
  $('#splitOptions').querySelectorAll('[data-split]').forEach(b=>b.onclick=()=>chooseSplit(b.dataset.split));
  $('#variantOptions').innerHTML=[0,1].map(v=>`<button class="variant-choice ${r.selectedSplit&&Number(r.splitVariant||0)===v?'active':''}" data-variant="${v}">${v?'B':'A'} 운동</button>`).join('');
  $('#variantOptions').querySelectorAll('[data-variant]').forEach(b=>b.onclick=()=>chooseVariant(+b.dataset.variant));
  const locked=r.programVersion!==370&&hasExerciseData(r);
  $('#splitNote').innerHTML=locked?'<b>이전 구성의 기록</b> 이미 입력한 운동명과 세트 기록을 보존합니다. 새 날짜에서 선택하면 수정한 구성이 나옵니다.':r.selectedSplit?`<b>${splitInfo[r.selectedSplit].title}</b> · ${Number(r.splitVariant||0)?'B':'A'} 구성<br>큰 동작 휴식 90초 · 작은 동작 60초`:'<b>자유 선택</b> 요일에 관계없이 부위와 A/B를 고르세요.';
  $('#absPicker370').classList.toggle('hidden',!r.selectedSplit||locked);
  $('#absOptions370').innerHTML=['none','A','B','C'].map(v=>`<button class="variant-choice ${r.absVariant===v?'active':''}" data-abs370="${v}" aria-pressed="${r.absVariant===v}">${v==='none'?'오늘 복근 쉬기':'복근 '+v}</button>`).join('');
  $('#absOptions370').querySelectorAll('[data-abs370]').forEach(b=>b.onclick=()=>chooseAbs370(b.dataset.abs370));
  $('#absDescription370').textContent=program370.abs[r.absVariant]?.ex.map(e=>e[0]).join(' · ')||'복근을 하는 날에는 A/B/C 중 하나를 선택하세요. 주 3회 안팎, 약 48시간 간격을 권장합니다.';
};
renderPlanNavigation=()=>{
  const start=mondayOf(new Date());start.setDate(start.getDate()+planWeekOffset*7);const end=new Date(start);end.setDate(end.getDate()+6);
  $('#planWeekRange').textContent=`${ymd(start)} ~ ${ymd(end)}`;$('#toggleOctoberPlan').textContent=octoberPlanOpen?'전체 운동 구성 닫기':'전체 운동 구성 보기';$('#octoberPlan').classList.toggle('hidden',!octoberPlanOpen);if(!octoberPlanOpen)return;
  $('#octoberPlan').innerHTML=Object.entries(splitInfo).map(([key,info])=>`<article class="month-plan-week"><h3>${info.title}</h3><div class="month-plan-days">${splitPrograms[key].map((p,i)=>`<button class="month-plan-day" data-choose-split="${key}" data-choose-variant="${i}"><b>${info.label} ${i?'B':'A'}</b><small>${p.ex.map(e=>e[0]+' '+e[1]).join(' · ')}</small></button>`).join('')}</div></article>`).join('')+Object.entries(program370.abs).map(([key,p])=>`<article class="month-plan-week"><h3>복근 ${key}</h3><p>${p.ex.map(e=>e[0]+' '+e[1]).join('<br>')}</p></article>`).join('');
  $('#octoberPlan').querySelectorAll('[data-choose-split]').forEach(b=>b.onclick=()=>chooseOverviewStrength370(b.dataset.chooseSplit,+b.dataset.chooseVariant));
};
exerciseDetail=(e,x,i,extra=false)=>{
  const detail=program370.details[e[0]];if(!detail)return baseExerciseDetail370(e,x,i,extra);
  return `<div class="exercise-details"><div class="step-grid">${detail.steps.map((t,n)=>`<figure class="step-photo"><figcaption>${n+1}단계</figcaption>${exercisePhotoMarkup(e[2],e[0],n)}</figure>`).join('')}</div><div class="motion-guide"><span>사진을 눌러 확대</span><b>· 순서대로 넘기기</b></div><div class="card-body"><div class="title-row"><div class="exercise-title"><div class="sets">${e[1]}</div></div><button class="check" ${extra?`data-extra-check="${i}"`:`data-check="${i}"`}>${x.done?'완료됨 ✓':'운동 완료'}</button></div>${exerciseTargetHtml(e[0])}<ol class="mobility-steps">${detail.steps.map(t=>`<li>${t}</li>`).join('')}</ol><p class="method"><b>운동 방법</b><br>${e[3]}</p><ul class="cues">${e[4].map(c=>`<li>${c}</li>`).join('')}</ul><p class="breathing"><b>호흡법</b><br>${detail.breathing}</p><p class="tip">세트 사이 휴식 ${detail.restSeconds||60}초</p>${setInputs(x,i,extra,e)}</div></div>`;
};
setInputs=(x,i,extra,e)=>{
  const detail=program370.details[e?.[0]];if(!detail)return baseSetInputs370(x,i,extra,e);
  const count=Number(e[1].match(/(\d+)세트/)?.[1]||detail.setCount||1),mode=detail.mode||'reps';
  const fields=mode==='seconds'?(detail.perSide?[['secondsLeft','왼쪽 초'],['secondsRight','오른쪽 초']]:[['seconds','시간 초']]):mode==='distance'?[['weight','중량 kg'],['meters','거리 m']]:[['weight',detail.assisted?'보조중량 kg':'중량 kg'],['reps',detail.perSide?'한쪽 반복':'반복'],['rir','여유횟수']];
  return `<div class="set-grid" style="grid-template-columns:34px repeat(${fields.length},minmax(0,1fr))"><span>세트</span>${fields.map(([,label])=>`<span>${label}</span>`).join('')}${Array.from({length:count},(_,n)=>`<span>${n+1}</span>${fields.map(([key,label])=>`<input aria-label="${e[0]} ${n+1}세트 ${label}" inputmode="decimal" data-set-ex="${i}" data-set-n="${n}" data-set-k="${key}" data-extra="${extra?1:0}" value="${x.sets?.[n]?.[key]||(n===0?x[key]||'':'')}">`).join('')}`).join('')}</div>`;
};
setText=x=>(x.sets?.length?x.sets:[{weight:x.weight,reps:x.reps}]).map((s,i)=>{
  const prefix=`${i+1}세트 `;
  if(s.secondsLeft||s.secondsRight)return prefix+`왼쪽 ${s.secondsLeft||'-'}초 · 오른쪽 ${s.secondsRight||'-'}초`;
  if(s.seconds)return prefix+`${s.seconds}초`;
  if(s.meters)return prefix+`${s.weight?s.weight+'kg · ':''}${s.meters}m`;
  return s.weight||s.reps?prefix+`${s.weight||'-'}kg × ${s.reps||'-'}회${s.rir?` (여유 ${s.rir}회)`:''}`:'';
}).filter(Boolean).join(', ');
previousExerciseRecord=name=>{
  for(const r of allRecords().filter(x=>x.date<selectedDate()))for(const entry of workoutRecords(r)){const p=recordPlan(entry),i=p?.ex?.findIndex(e=>e[0]===name)??-1,x=entry.exercises?.[i];if(i>=0&&hasExerciseData({exercises:[x]}))return {date:r.date,data:x};}return null;
};
weightAdvice=(e,previous)=>{
  const detail=program370.details[e[0]];
  if(detail?.assisted)return '보조중량이 클수록 쉽습니다. 모든 세트에서 10회를 편안하게 수행하면 보조중량을 한 단계 줄이세요.';
  if(detail?.mode==='seconds')return '자세와 호흡을 유지할 수 있는 시간만 버팁니다. 목표 상한 시간이 편해지면 조금씩 늘리세요.';
  if(detail?.mode==='distance')return '상체를 세우고 흔들림 없이 목표 거리를 걷습니다. 중량보다 자세를 먼저 유지하세요.';
  if(e[0]==='케이블 크런치'||e[0]==='중량 슬로우 크런치')return '모든 세트에서 15회를 정확히 수행하면 가장 작은 단위로 중량을 올리세요. 목으로 당기지 않습니다.';
  return baseWeightAdvice370(e,previous);
};
render=()=>{
  baseRender370();const r=getRecord(),activity=selectedActivity(r);document.getElementById('absGuidance')?.remove();
  $('#homePicker370').classList.toggle('hidden',activity!=='home');
  if(activity==='home'){
    $('#homeOptions370').innerHTML=['recovery','core'].map(v=>`<button class="variant-choice ${r.homeVariant===v?'active':''}" data-home370="${v}" aria-pressed="${r.homeVariant===v}">${v==='core'?'코어 홈트':'회복 홈트'}</button>`).join('');
    $('#homeOptions370').querySelectorAll('[data-home370]').forEach(b=>b.onclick=()=>chooseHome370(b.dataset.home370));
    $('#runBox').innerHTML=`<div class="run"><div class="run-head"><strong>🏠 ${recordPlan(r).title}</strong><span class="badge">점프·도구 없음</span></div><p>${r.homeVariant==='core'?'브리지와 버티기 동작으로 몸통을 안정시킵니다. 헬스장 복근을 쉰 날에 선택하세요.':'척추·고관절·종아리를 부드럽게 풀어줍니다. 몸 상태에 맞게 어느 날이든 선택하세요.'}</p><p class="tip">약 15분 · 운동명을 누르면 4단계 사진과 설명이 열립니다.</p></div>`;
  }
  if(activity==='strength'&&program370.abs[r.absVariant]){
    const guide=document.createElement('div');guide.id='absGuidance';guide.className='run';guide.innerHTML=`<strong>복근 ${r.absVariant} · 상복부·하복부·옆구리</strong><p>근력운동 뒤에 선택한 복근 3종을 진행합니다. ${program370.abs[r.absVariant].meta}</p><p class="tip">주 3회 안팎, 약 48시간 간격. 복부 피로가 남았다면 ‘오늘 복근 쉬기’를 선택하세요.</p>`;list.before(guide);
  }
};
