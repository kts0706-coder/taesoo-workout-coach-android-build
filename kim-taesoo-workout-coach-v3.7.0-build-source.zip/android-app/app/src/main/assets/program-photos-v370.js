// Four stages: upper left, upper right, lower left, lower right.
window.program370Photos = Object.fromEntries([
  'ab_rollout', 'assisted_pullup', 'bear_plank', 'cable_crunch',
  'cable_lateral', 'down_dog', 'hanging_knee', 'heel_slide',
  'open_book', 'seated_calf', 'side_plank', 'single_bridge',
  'weighted_crunch', 'woodchop'
].map(name => ['pdf370_' + name, [1536, 1024]]));
