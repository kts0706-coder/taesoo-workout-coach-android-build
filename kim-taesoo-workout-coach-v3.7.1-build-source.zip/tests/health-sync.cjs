// Real bridge callbacks: a failed section must not discard a successful one.
const {harness} = require('./app-harness.cjs');
const {run} = harness();
run(`
assert.ok(window.healthSync371,'health adapter must load before the UI bootstrap');
render=()=>{};renderDayHealth=()=>{};renderRecovery=()=>{};show=()=>{};
const keys=['weightKg','bodyFatPercent','stepsToday','sleepMinutes','restingHeartRate','vo2Max'];
const time='2026-09-23T02:00:00.000Z';
const measuredAt='2026-09-22T22:00:00.000Z';
const meta=status=>Object.fromEntries(keys.map(key=>[key,{status,measuredAt,readAt:time,sourceName:'삼성헬스',sourcePackage:'com.sec.android.app.shealth'}]));
const wellness={weightKg:72,bodyFatPercent:19,stepsToday:1800,sleepMinutes:430,restingHeartRate:61,vo2Max:44,meta:meta('ok')};
const payload={schemaVersion:2,readAt:time,syncedAt:time,activitiesStatus:'ok',historyDays:365,wellness,activities:[
 {id:'session-old',date:'2026-08-01',type:'근력 운동',isStrength:true,minutes:32},
 {id:'session-current',date:'2026-09-23',type:'근력 운동',isStrength:true,minutes:40}
]};
const health=()=>JSON.parse(localStorage.getItem(healthWellnessKey));
const sessions=()=>JSON.parse(localStorage.getItem(healthStoreKey));
const state=()=>JSON.parse(localStorage.getItem('taesoo-health-read-state'));
assert.equal(window.receiveSamsungHealthData(payload),true);
assert.equal(health().weightKg,72);
assert.equal(health().bodyFatPercent,19);
assert.equal(health().meta.weightKg.measuredAt,measuredAt,'measurement date is distinct from read time');
assert.equal(health().meta.weightKg.sourcePackage,'com.sec.android.app.shealth');
assert.equal(health().meta.weightKg.cached,false);
assert.equal(sessions().length,2);

// A new body reading survives an exercise permission failure; logs remain intact.
const next={...payload,readAt:'2026-09-23T02:01:00.000Z',activitiesStatus:'permission_denied',activities:[],wellness:{...wellness,weightKg:71.5}};
assert.equal(window.receiveSamsungHealthData(next),true);
assert.equal(health().weightKg,71.5);
assert.equal(sessions().length,2,'failed activity read preserves imported history');
assert.equal(state().activitiesStatus,'permission_denied');

// A failed metric keeps its last real measurement, explicitly marked as cached.
const partial={...next,readAt:'2026-09-23T02:02:00.000Z',wellness:{...wellness,weightKg:null,bodyFatPercent:18.5,
 meta:{...meta('ok'),weightKg:{status:'error',readAt:'2026-09-23T02:02:00.000Z'}}}};
window.receiveSamsungHealthData(partial);
assert.equal(health().weightKg,71.5);
assert.equal(health().bodyFatPercent,18.5,'successful metrics update independently');
assert.equal(health().meta.weightKg.cached,true);
assert.equal(health().meta.weightKg.status,'error');
assert.equal(health().meta.weightKg.measuredAt,measuredAt,'cached value keeps its actual measurement date');
assert.equal(health().meta.weightKg.sourceName,'삼성헬스');
assert.ok(window.healthSync371.metricHTML('weightKg','최근 체중',health()).includes('이전 조회값'));
const denied=window.healthSync371.mergeWellness(health(),{meta:{weightKg:{status:'permission_denied'}}});
assert.equal(denied.weightKg,71.5);
assert.equal(denied.meta.weightKg.cached,true);
assert.equal(denied.meta.weightKg.status,'permission_denied');

// A successful empty result is not an error and must clear a stale measurement.
window.receiveSamsungHealthData({...partial,readAt:'2026-09-23T02:03:00.000Z',wellness:{...wellness,weightKg:null,meta:{...meta('ok'),weightKg:{status:'empty'}}}});
assert.equal(health().weightKg,null);
assert.equal(health().meta.weightKg.cached,false);
assert.equal(health().meta.weightKg.status,'empty');

// A delayed response cannot overwrite any newer value, timestamp, or activity.
const before=JSON.stringify({...localStorage});
assert.equal(window.receiveSamsungHealthData(payload),false);
assert.equal(JSON.stringify({...localStorage}),before);
assert.equal(window.receiveSamsungHealthData({...payload,readAt:'invalid'}),false);
assert.equal(window.receiveSamsungHealthData(null),false);
assert.equal(JSON.stringify({...localStorage}),before);

// Restricted-history reads update matching IDs and retain older imported sessions.
window.receiveSamsungHealthData({...payload,readAt:'2026-09-23T02:04:00.000Z',historyDays:30,activities:[
 {id:'session-current',date:'2026-09-23',type:'근력 운동',isStrength:true,minutes:41}
]});
assert.equal(sessions().length,2,'30-day limit does not erase the older session');
assert.equal(sessions().find(x=>x.id==='session-current').minutes,41);
assert.equal(getRecord('2026-09-23').healthStrength.sessions,1,'same session is not double counted');
assert.equal(getRecord('2026-09-23').healthStrength.minutes,41);
assert.equal(state().historyDays,30);

// Provider names and alternative metadata are data, never executable markup.
const evil='<img src=x onerror="alert(1)">';
const safe=window.healthSync371.metricHTML('weightKg','최근 체중',{weightKg:72,meta:{weightKg:{status:'ok',sourceName:evil,measuredAt,
 alternatives:[{value:73,sourceName:evil,sourcePackage:evil,measuredAt:time}]}}});
assert.ok(!safe.includes('<img'));
assert.ok(safe.includes('&lt;img'));
assert.ok(safe.includes('다른 출처의 기록'));
assert.ok(safe.includes('72.0 kg')&&safe.includes('73.0 kg'),'alternative source is distinguished from primary');
assert.equal(window.healthSync371.valueText('weightKg',null),'—');
assert.equal(window.healthSync371.valueText('weightKg','NaN'),'—');
assert.equal(window.healthSync371.valueText('stepsToday',0),'0 보');
window.receiveHealthStatus({message:'헬스 커넥트 불러오는 중',connected:true,busy:true});
assert.equal($('#syncHealth').disabled,true);
window.receiveHealthStatus({message:'조회 완료',connected:true,busy:false});
assert.equal($('#syncHealth').disabled,false);
`);
console.log('PASS: independent health sections, cached/error labels, empty clearing, ordering, history merge and metadata escaping');
