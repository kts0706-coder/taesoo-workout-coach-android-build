// The health-sync upgrade must retain the v3.7 plans and their saved identities.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {harness, assets} = require('./app-harness.cjs');
const {run} = harness();
run(`
const testDate='2026-09-23';
selectedDate=()=>testDate;day=2;render=()=>{};show=()=>{};
const seed=r=>localStorage.setItem(journalKey(testDate),JSON.stringify({date:testDate,day:2,...r}));
const names=p=>p.ex.map(e=>e[0]);
assert.equal(Object.values(program370.strength).flat().length,6);
assert.deepEqual(Object.keys(program370.abs),['A','B','C']);
assert.deepEqual(Object.keys(program370.home),['recovery','core']);
const allPlans=Object.values(program370.strength).flat().concat(Object.values(program370.abs),Object.values(program370.home));
for(const p of allPlans){
 assert.ok(p.ex.length>0,p.title+' retains movements');
 assert.equal(new Set(names(p)).size,p.ex.length,p.title+' has no duplicates');
 for(const e of p.ex){
  assert.ok(!/버드독|데드버그/.test(e[0]),'retired movements must not return');
  const d=program370.details[e[0]];
  assert.ok(d&&d.targets.length===2&&d.breathing,e[0]+' retains target and breathing');
  assert.equal(d.steps.length,4,e[0]+' retains four instructions');
  assert.ok(exerciseDetail(e,{},0).includes('data-photo'),e[0]+' retains photo entry point');
 }
}

// A v3.6 log retains its recorded movement and numbers after any health upgrade.
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,corePlanVersion:2,
 exercises:[{done:true,sets:[{weight:'17',reps:'9'}]}]});
let before=recordPlan(getRecord());
assert.equal(before.title,v360Splits.chest[0].title);
chooseActivity('home');chooseActivity('strength');
assert.equal(recordPlan(getRecord()).title,before.title);
assert.equal(getRecord().exercises[0].sets[0].weight,'17');
assert.equal(getRecord().exercises[0].sets[0].reps,'9');

// Selecting abs changes its own rows while keeping the primary workout intact.
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,programVersion:370,corePlanVersion:2,absVariant:'none',exercises:[]});
let r=getRecord();r.exercises[0]={done:true,sets:[{weight:'18',reps:'10'}]};saveRecord(r);
chooseAbs370('A');r=getRecord();
const baseCount=program370.strength.chest[0].ex.length;
r.exercises[baseCount]={done:true,sets:[{weight:'10',reps:'13'}]};saveRecord(r);
chooseAbs370('B');
assert.equal(getRecord().exercises[0].sets[0].weight,'18');
assert.equal(getRecord().exercises[baseCount],undefined,'new abs choice cannot borrow old rows');
chooseAbs370('A');
assert.equal(getRecord().exercises[baseCount].sets[0].reps,'13');
chooseActivity('home');chooseHome370('core');
r=getRecord();r.exercises[0]={done:true,sets:[{seconds:'31'}]};saveRecord(r);
chooseHome370('recovery');r=getRecord();r.exercises[0]={done:true,sets:[{seconds:'42'}]};saveRecord(r);
chooseHome370('core');
assert.equal(getRecord().exercises[0].sets[0].seconds,'31');
chooseActivity('strength');
assert.equal(getRecord().exercises[0].sets[0].weight,'18');
assert.equal(getRecord().exercises[baseCount].sets[0].reps,'13');
const history=workoutRecords(getRecord());
assert.ok(history.some(x=>x.homeVariant==='core'&&x.exercises[0]?.sets[0]?.seconds==='31'));
assert.ok(history.some(x=>x.homeVariant==='recovery'&&x.exercises[0]?.sets[0]?.seconds==='42'));
const historical=[['보존할 운동 이름','2세트 × 10회','1_1.jpg','기록 당시 방법',[]]];
seed({selectedActivity:'strength',selectedSplit:'legs',splitVariant:1,programVersion:370,
 exercises:[{done:true,sets:[{weight:'23',reps:'8'}]}],planExercises:historical,planMeta:{title:'저장 당시 구성'}});
saveRecord(getRecord());
assert.equal(recordPlan(getRecord()).ex[0][0],'보존할 운동 이름');
assert.equal(getRecord().exercises[0].sets[0].weight,'23');
`);
for (const name of run('Object.keys(window.program370Photos)')) {
  assert.ok(fs.existsSync(path.join(assets, 'images4', name + '.png')), 'Photo exists: ' + name);
}
console.log('PASS: v3.7 programs/photos, v3.6 history, independent abs/Home variants and saved snapshots');
