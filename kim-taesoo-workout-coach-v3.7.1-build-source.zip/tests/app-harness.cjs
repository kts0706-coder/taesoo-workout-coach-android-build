// Execute real app scripts, in browser order, without attaching the UI bootstrap.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const assets = path.join(__dirname, '../android-app/app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)].map((match, i) => {
  const src = match[1].match(/\bsrc=["']([^"']+)["']/)?.[1];
  const code = src ? fs.readFileSync(path.join(assets, src), 'utf8') : match[2];
  const filename = src || 'inline-' + i + '.js';
  new vm.Script(code, {filename});
  return {src, code, filename};
});
function harness({legacy = false, globals = {}} = {}) {
  const storage = Object.create(null);
  Object.defineProperties(storage, {
    getItem: {value: key => storage[key] ?? null},
    setItem: {value: (key, value) => {storage[key] = String(value);}},
    removeItem: {value: key => {delete storage[key];}},
    clear: {value: () => Object.keys(storage).forEach(key => delete storage[key])}
  });
  const elements = new Map();
  function element(selector) {
    if (!elements.has(selector)) {
      const classes = new Set();
      elements.set(selector, {
        innerHTML: '', textContent: '', disabled: false, dataset: {},
        classList: {
          add: (...names) => names.forEach(name => classes.add(name)),
          remove: (...names) => names.forEach(name => classes.delete(name)),
          contains: name => classes.has(name),
          toggle: (name, on) => {if (on ?? !classes.has(name)) classes.add(name); else classes.delete(name);}
        },
        style: {setProperty() {}}, querySelectorAll: () => [],
        querySelector: nested => element(selector + ' ' + nested),
        setAttribute() {}, addEventListener() {}, before() {}, remove() {}
      });
    }
    return elements.get(selector);
  }
  const document = {
    querySelector: element, querySelectorAll: () => [],
    getElementById: id => element('#' + id), createElement: tag => element('new-' + tag),
    body: element('body'), head: element('head'), addEventListener() {}
  };
  const context = vm.createContext({
    assert, console, localStorage: storage, window: {}, document,
    confirm: () => true, setTimeout: () => 0, clearTimeout() {},
    ...globals
  });
  let sawBootstrap = false;
  for (const script of scripts) {
    const bootstrap = script.code.indexOf("  document.querySelectorAll('.view-btn')");
    if (bootstrap >= 0) {
      sawBootstrap = true;
      if (script.code.slice(0, bootstrap).trim()) vm.runInContext(script.code.slice(0, bootstrap), context, {filename: script.filename});
      break;
    }
    if (!legacy || !script.src) vm.runInContext(script.code, context, {filename: script.filename});
  }
  assert.ok(sawBootstrap, 'Expected app bootstrap after declarations/adapters');
  return {context, storage, elements, element, run: code => vm.runInContext(code, context)};
}
module.exports = {harness, assets, scripts};
