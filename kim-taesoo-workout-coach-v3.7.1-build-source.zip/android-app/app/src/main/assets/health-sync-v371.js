/* Health Connect read results are separate from measurement dates. */
(() => {
  const keys=['weightKg','bodyFatPercent','stepsToday','sleepMinutes','restingHeartRate','vo2Max'];
  const stateKey='taesoo-health-read-state';
  const readJSON=(key,fallback={})=>{try{return JSON.parse(localStorage.getItem(key)||'null')||fallback}catch{return fallback}};
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const stamp=value=>{const d=new Date(value);return value&&Number.isFinite(d.getTime())?d.toLocaleString('ko-KR',{year:'numeric',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'}):'측정일 정보 없음'};
  const numeric=v=>v!==null&&v!==''&&v!==undefined&&Number.isFinite(Number(v));
  const valueText=(key,value)=>{
    if(!numeric(value))return '—';const v=Number(value);
    if(key==='weightKg')return `${v.toFixed(1)} kg`;
    if(key==='bodyFatPercent')return `${v.toFixed(1)}%`;
    if(key==='stepsToday')return `${Math.round(v).toLocaleString('ko-KR')} 보`;
    if(key==='sleepMinutes')return `${Math.floor(v/60)}시간 ${Math.round(v%60)}분`;
    if(key==='restingHeartRate')return `${Math.round(v)} bpm`;
    return v.toFixed(1);
  };
  function mergeWellness(previous={},incoming={}){
    const result={meta:{}};
    for(const key of keys){
      const meta=incoming.meta?.[key]||{status:Object.prototype.hasOwnProperty.call(incoming,key)?(incoming[key]==null?'empty':'ok'):'error'};
      if(['error','permission_denied'].includes(meta.status)){
        result[key]=numeric(previous[key])?previous[key]:null;
        result.meta[key]={...previous.meta?.[key],...meta,measuredAt:previous.meta?.[key]?.measuredAt,sourceName:previous.meta?.[key]?.sourceName,sourcePackage:previous.meta?.[key]?.sourcePackage,cached:result[key]!=null};
      }else{
        result[key]=meta.status==='ok'&&numeric(incoming[key])?Number(incoming[key]):null;
        result.meta[key]={...meta,cached:false};
      }
    }
    return result;
  }
  function metricHTML(key,label,w){
    const m=w.meta?.[key]||{},value=w[key];
    const messages={permission_denied:'읽기 권한이 꺼져 있습니다',error:'이번 조회에 실패했습니다',empty:'공유된 기록이 없습니다'};
    const status=messages[m.status]||(m.status==='ok'?'': '다시 조회해 측정일을 확인하세요');
    const source=m.sourceName||m.sourcePackage||(m.status==='ok'?'삼성헬스':'출처 확인 전');
    const date=key==='stepsToday'?((m.rangeEnd||m.measuredAt)?`${stamp(m.rangeEnd||m.measuredAt)} 기준`:'집계 날짜 확인 전'):stamp(m.measuredAt);
    return `<div class="health-metric"><span>${label}</span><b>${valueText(key,value)}</b><small>${escape(date)}</small><small>${escape(source)}</small>${status?`<p class="metric-status">${m.cached?'이전 조회값 · ':''}${escape(status)}</p>`:''}${(m.alternatives||[]).map(a=>`<div class="metric-alternative">다른 출처의 기록<br><strong>${valueText(key,a.value)}</strong> · ${escape(a.sourceName||a.sourcePackage||'출처 미상')}<br>${escape(stamp(a.measuredAt))}</div>`).join('')}</div>`;
  }
  renderHealth=function(){
    const rows=healthActivities(),w=readJSON(healthWellnessKey),state=readJSON(stateKey);
    const labels=['최근 체중','최근 체지방률','오늘 걸음 수','최근 수면','안정시 심박수','최근 VO₂ Max'];
    $('#healthMetrics').innerHTML=keys.map((k,i)=>metricHTML(k,labels[i],w)).join('');
    $('#healthCount').textContent=`${rows.length}회`;
    $('#healthHistory').innerHTML=rows.length?rows.map(x=>activityCard(x)).join(''):'<div class="empty">헬스 커넥트에 공유된 삼성헬스 운동 기록이 여기에 표시됩니다.</div>';
    const synced=localStorage.getItem('taesoo-health-synced');
    $('#syncTime').textContent=synced?`마지막 조회 ${stamp(synced)} · 측정 날짜는 아래에서 확인하세요`:'';
    const notes=[];
    if(state.activitiesStatus&&state.activitiesStatus!=='ok')notes.push('운동 기록은 이번에 읽지 못해 이전 조회 기록을 표시합니다.');
    if(state.aggregateErrors)notes.push('일부 운동의 거리·심박수 등 상세 수치는 이번에 읽지 못했습니다.');
    if(state.historyDays===30)notes.push('허용된 최근 30일 기록을 조회했습니다. 이전에 불러온 기록은 보관됩니다.');
    $('#healthReadNotice').textContent=notes.join(' ');
  };
  window.receiveSamsungHealthData=function(data){
    if(!data||typeof data!=='object')return false;
    const readAt=data.readAt||data.syncedAt,time=Date.parse(readAt),previous=readJSON(stateKey);
    if(!Number.isFinite(time)||time<(Date.parse(previous.readAt)||0))return false;
    const merged=mergeWellness(readJSON(healthWellnessKey),data.wellness||{});
    localStorage.setItem(healthWellnessKey,JSON.stringify(merged));
    localStorage.setItem('taesoo-health-synced',data.syncedAt||readAt);
    const activitiesStatus=data.activitiesStatus||(Array.isArray(data.activities)?'ok':'error');
    localStorage.setItem(stateKey,JSON.stringify({readAt,activitiesStatus,historyDays:data.activitiesReadDays||data.historyDays||data.activitiesHistoryDays,aggregateErrors:data.activityAggregateErrors||0}));
    if(activitiesStatus==='ok'&&Array.isArray(data.activities)){
      // A restricted history window must not erase already imported older sessions.
      const byId=new Map(healthActivities().map(x=>[x.id,x]));
      data.activities.forEach(x=>{if(x&&x.id)byId.set(x.id,x)});
      importHealthActivities([...byId.values()].sort((a,b)=>String(b.date).localeCompare(String(a.date))));
    }else{renderHealth();}
    const partial=activitiesStatus!=='ok'||keys.some(k=>['error','permission_denied'].includes(merged.meta[k].status));
    show(partial?'일부 항목을 읽지 못했습니다. 연동 상태를 확인하세요.':'건강정보를 조회했습니다. 측정 날짜를 확인하세요.');
    return true;
  };
  window.receiveHealthStatus=function(data){
    $('#healthStatus').textContent=data.message||'';
    $('#healthDot').classList.toggle('on',!!data.connected);
    const busy=data.busy===true||data.message?.includes('불러오는 중');
    $('#syncHealth').disabled=!!busy;
    $('#syncHealth').textContent=busy?'조회 중…':'지금 동기화';
    $('#connectHealth').textContent=data.connected?'읽기 권한 다시 확인':'읽기 권한 허용하기';
  };
  window.healthSync371={mergeWellness,metricHTML,valueText};
})();
