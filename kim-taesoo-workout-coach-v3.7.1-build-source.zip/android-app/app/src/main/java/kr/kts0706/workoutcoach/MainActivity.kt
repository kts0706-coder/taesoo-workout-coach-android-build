package kr.kts0706.workoutcoach

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.aggregate.AggregateMetric
import androidx.health.connect.client.aggregate.AggregationResult
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.BodyFatRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.ElevationGainedRecord
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.StepsCadenceRecord
import androidx.health.connect.client.records.Vo2MaxRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.round
import kotlin.reflect.KClass

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var healthClient: HealthConnectClient? = null
    private val samsungPackage = "com.sec.android.app.shealth"
    private val samsungHealthOrigin = setOf(DataOrigin(samsungPackage))
    private var pageReady = false
    private var foreground = false
    private var pendingPermissionRequest = false
    private var syncJob: Job? = null
    private val sourceNames = mutableMapOf<String, String>()

    private val permissions = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(StepsCadenceRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class)
    )

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { _ ->
        // Query the current grants again; denied optional metrics must not block allowed data.
        connectAndSync(false)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val backgroundColor = Color.rgb(11, 17, 24)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        window.setBackgroundDrawable(ColorDrawable(backgroundColor))
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val root = FrameLayout(this).apply { setBackgroundColor(backgroundColor) }
        webView = WebView(this).apply { setBackgroundColor(backgroundColor) }
        root.addView(webView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, windowInsets ->
            val types = WindowInsetsCompat.Type.systemBars() or
                WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            val insets = windowInsets.getInsets(types)
            view.setPadding(insets.left, insets.top, insets.right, insets.bottom)
            // Native padding keeps every WebView overlay above the system UI.
            // Forward zeroed values so WebView does not apply the same insets again.
            WindowInsetsCompat.Builder(windowInsets)
                .setInsets(types, Insets.NONE)
                .build()
        }
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(HealthBridge(), "AndroidHealth")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                pageReady = false
                syncJob?.cancel()
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = url == "file:///android_asset/index.html"
                if (pageReady) connectAndSync(false)
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        foreground = true
        if (::webView.isInitialized) connectAndSync(false)
    }

    override fun onPause() {
        foreground = false
        // Only foreground reads are requested. A cancelled older read cannot replace newer data.
        syncJob?.cancel()
        super.onPause()
    }

    inner class HealthBridge {
        @JavascriptInterface fun connect() = runOnUiThread { connectAndSync(true) }
        @JavascriptInterface fun sync() = runOnUiThread { connectAndSync(false) }
        @JavascriptInterface fun isNativeApp(): Boolean = true
        @JavascriptInterface fun openHealthConnectSettings() = runOnUiThread {
            launchHealthScreen(Intent(HealthConnectClient.getHealthConnectSettingsAction()), "Health Connect 설정을 열 수 없습니다. 휴대폰 설정에서 Health Connect를 검색해 주세요.")
        }
        @JavascriptInterface fun openSamsungHealth() = runOnUiThread {
            val intent = packageManager.getLaunchIntentForPackage(samsungPackage)
            if (intent == null) sendStatus("삼성헬스를 열 수 없습니다. 휴대폰에서 삼성헬스를 직접 열어 주세요.", false)
            else launchHealthScreen(intent, "삼성헬스를 열 수 없습니다. 휴대폰에서 직접 열어 주세요.")
        }
    }

    private fun launchHealthScreen(intent: Intent, failure: String) {
        try { startActivity(intent) } catch (_: Exception) { sendStatus(failure, false) }
    }

    private fun connectAndSync(requestIfMissing: Boolean) {
        pendingPermissionRequest = pendingPermissionRequest || requestIfMissing
        if (!pageReady || !foreground) return
        if (syncJob?.isActive == true) return
        val shouldRequest = pendingPermissionRequest
        pendingPermissionRequest = false
        if (HealthConnectClient.getSdkStatus(this) != HealthConnectClient.SDK_AVAILABLE) {
            sendStatus("Health Connect를 사용할 수 없습니다", false)
            return
        }
        val client = HealthConnectClient.getOrCreate(this)
        healthClient = client
        syncJob = lifecycleScope.launch {
            val thisJob = currentCoroutineContext()[Job]
            try {
                val granted = client.permissionController.getGrantedPermissions()
                if (shouldRequest && !granted.containsAll(permissions)) {
                    permissionLauncher.launch(permissions - granted)
                    return@launch
                }
                syncHealth(client, granted)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                sendStatus("Health Connect에 연결하지 못했습니다. 설정과 권한을 확인해 주세요.", false)
            } finally {
                if (syncJob === thisJob) {
                    syncJob = null
                    if (pendingPermissionRequest && foreground && pageReady) {
                        webView.post { connectAndSync(false) }
                    }
                }
            }
        }
    }

    private data class ReadWindow<T : Record>(
        val records: List<T>, val days: Long, val start: Instant, val historyFallback: Boolean
    )

    private suspend fun <T : Record> readPages(
        client: HealthConnectClient, type: KClass<T>, start: Instant, end: Instant,
        origins: Set<DataOrigin>
    ): List<T> {
        val records = mutableListOf<T>()
        val seenTokens = mutableSetOf<String>()
        var token: String? = null
        do {
            val response = client.readRecords(ReadRecordsRequest(
                recordType = type,
                timeRangeFilter = TimeRangeFilter.between(start, end),
                dataOriginFilter = origins,
                ascendingOrder = false,
                pageSize = 1000,
                pageToken = token
            ))
            records.addAll(response.records)
            token = response.pageToken?.takeIf { it.isNotEmpty() }
            check(token == null || seenTokens.add(token)) { "Repeated Health Connect page token" }
        } while (token != null)
        return records
    }

    private suspend fun <T : Record> readWindow(
        client: HealthConnectClient, type: KClass<T>, end: Instant,
        days: Long = 365, origins: Set<DataOrigin> = samsungHealthOrigin
    ): ReadWindow<T> {
        val start = end.minus(Duration.ofDays(days))
        return try {
            ReadWindow(readPages(client, type, start, end, origins), days, start, false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (days <= 30) throw e
            // Do not request broader history access. Retry a supported recent range instead.
            val recentStart = end.minus(Duration.ofDays(30))
            ReadWindow(readPages(client, type, recentStart, end, origins), 30, recentStart, true)
        }
    }

    private fun <T : Record> allowed(granted: Set<String>, type: KClass<T>) =
        HealthPermission.getReadPermission(type) in granted

    @Suppress("DEPRECATION")
    private fun sourceName(packageName: String): String = sourceNames.getOrPut(packageName) {
        if (packageName == samsungPackage) "삼성헬스"
        else try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
        } catch (_: Exception) { packageName }
    }

    private fun metricMeta(status: String, readAt: Instant): JSONObject = JSONObject().apply {
        put("status", status)
        put("readAt", readAt.toString())
        put("measuredAt", JSONObject.NULL)
        put("sourcePackage", samsungPackage)
        put("sourceName", "삼성헬스")
    }

    private suspend fun <T : Record> readLatestMetric(
        client: HealthConnectClient, granted: Set<String>, type: KClass<T>, key: String,
        wellness: JSONObject, meta: JSONObject, end: Instant,
        days: Long = 365, includeAlternatives: Boolean = false,
        measuredTime: (T) -> Instant, value: (T) -> Number
    ) {
        val info = metricMeta("permission_denied", Instant.now())
        meta.put(key, info)
        wellness.put(key, JSONObject.NULL)
        if (!allowed(granted, type)) return
        try {
            val window = readWindow(client, type, end, days)
            val latest = window.records.maxWithOrNull(compareBy<T> { measuredTime(it) }.thenBy { it.metadata.lastModifiedTime })
            info.put("status", if (latest == null) "empty" else "ok")
            info.put("daysRead", window.days)
            info.put("rangeStart", window.start.toString())
            info.put("rangeEnd", end.toString())
            info.put("historyFallback", window.historyFallback)
            if (latest != null) {
                wellness.put(key, value(latest))
                info.put("measuredAt", measuredTime(latest).toString())
                info.put("lastModifiedAt", latest.metadata.lastModifiedTime.toString())
                info.put("sourcePackage", latest.metadata.dataOrigin.packageName)
                info.put("sourceName", sourceName(latest.metadata.dataOrigin.packageName))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            info.put("status", if (e is SecurityException) "permission_denied" else "error")
            info.put("errorCode", e.javaClass.simpleName)
        }
        if (includeAlternatives) {
            // Samsung Health can show measurements written by other apps. Keep candidates
            // separate: they must never silently replace a Samsung Health-origin value.
            try {
                val all = readWindow(client, type, end, days, emptySet())
                val alternatives = all.records.filter { it.metadata.dataOrigin.packageName != samsungPackage }
                    .groupBy { it.metadata.dataOrigin.packageName }
                    .mapNotNull { (_, rows) -> rows.maxWithOrNull(compareBy<T> { measuredTime(it) }.thenBy { it.metadata.lastModifiedTime }) }
                    .sortedByDescending { measuredTime(it) }
                info.put("alternatives", JSONArray().apply {
                    alternatives.forEach { candidate -> put(JSONObject().apply {
                        put("value", value(candidate))
                        put("measuredAt", measuredTime(candidate).toString())
                        put("sourcePackage", candidate.metadata.dataOrigin.packageName)
                        put("sourceName", sourceName(candidate.metadata.dataOrigin.packageName))
                    }) }
                })
                info.put("alternativesStatus", "ok")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                info.put("alternativesStatus", if (e is SecurityException) "permission_denied" else "error")
            }
        }
    }

    private suspend fun readWellness(
        client: HealthConnectClient, granted: Set<String>, end: Instant
    ): JSONObject {
        val wellness = JSONObject()
        val meta = JSONObject()
        wellness.put("meta", meta)
        readLatestMetric(client, granted, WeightRecord::class, "weightKg", wellness, meta, end,
            includeAlternatives = true, measuredTime = { it.time }, value = { it.weight.inKilograms })
        readLatestMetric(client, granted, BodyFatRecord::class, "bodyFatPercent", wellness, meta, end,
            includeAlternatives = true, measuredTime = { it.time }, value = { it.percentage.value })
        readLatestMetric(client, granted, RestingHeartRateRecord::class, "restingHeartRate", wellness, meta, end,
            measuredTime = { it.time }, value = { it.beatsPerMinute })
        readLatestMetric(client, granted, Vo2MaxRecord::class, "vo2Max", wellness, meta, end,
            measuredTime = { it.time }, value = { it.vo2MillilitersPerMinuteKilogram })
        readLatestMetric(client, granted, SleepSessionRecord::class, "sleepMinutes", wellness, meta, end,
            days = 7, measuredTime = { it.endTime }, value = { Duration.between(it.startTime, it.endTime).toMinutes() })
        val stepsMeta = metricMeta("permission_denied", Instant.now())
        meta.put("stepsToday", stepsMeta)
        wellness.put("stepsToday", JSONObject.NULL)
        if (allowed(granted, StepsRecord::class)) {
            try {
                val todayStart = end.atZone(ZoneId.systemDefault()).toLocalDate().atStartOfDay(ZoneId.systemDefault()).toInstant()
                val steps = client.aggregate(AggregateRequest(
                    setOf(StepsRecord.COUNT_TOTAL), TimeRangeFilter.between(todayStart, end),
                    dataOriginFilter = samsungHealthOrigin
                ))[StepsRecord.COUNT_TOTAL]
                stepsMeta.put("status", if (steps == null) "empty" else "ok")
                stepsMeta.put("rangeStart", todayStart.toString())
                stepsMeta.put("rangeEnd", end.toString())
                // An aggregate has no single measurement timestamp; rangeEnd is the query cutoff.
                wellness.put("stepsToday", steps ?: JSONObject.NULL)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                stepsMeta.put("status", if (e is SecurityException) "permission_denied" else "error")
                stepsMeta.put("errorCode", e.javaClass.simpleName)
            }
        }
        return wellness
    }

    private fun exerciseMetrics(granted: Set<String>): Set<AggregateMetric<*>> = buildSet {
        if (allowed(granted, DistanceRecord::class)) add(DistanceRecord.DISTANCE_TOTAL)
        if (allowed(granted, TotalCaloriesBurnedRecord::class)) add(TotalCaloriesBurnedRecord.ENERGY_TOTAL)
        if (allowed(granted, HeartRateRecord::class)) { add(HeartRateRecord.BPM_AVG); add(HeartRateRecord.BPM_MAX) }
        if (allowed(granted, SpeedRecord::class)) { add(SpeedRecord.SPEED_AVG); add(SpeedRecord.SPEED_MAX) }
        if (allowed(granted, StepsCadenceRecord::class)) { add(StepsCadenceRecord.RATE_AVG); add(StepsCadenceRecord.RATE_MAX) }
        if (allowed(granted, ElevationGainedRecord::class)) add(ElevationGainedRecord.ELEVATION_GAINED_TOTAL)
    }

    private suspend fun readActivities(
        client: HealthConnectClient, granted: Set<String>, end: Instant, payload: JSONObject
    ) {
        payload.put("activitiesStatus", "permission_denied")
        if (!allowed(granted, ExerciseSessionRecord::class)) return
        try {
            val window = readWindow(client, ExerciseSessionRecord::class, end)
            val rows = JSONArray()
            val metrics = exerciseMetrics(granted)
            var aggregateErrors = 0
            for (session in window.records) {
                var aggregate: AggregationResult? = null
                var aggregateStatus = if (metrics.isEmpty()) "permission_denied" else "ok"
                if (metrics.isNotEmpty()) {
                    try {
                        aggregate = client.aggregate(AggregateRequest(
                            metrics,
                            TimeRangeFilter.between(session.startTime, session.endTime),
                            dataOriginFilter = samsungHealthOrigin
                        ))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        aggregateErrors++
                        aggregateStatus = "error"
                    }
                }
                val durationSeconds = Duration.between(session.startTime, session.endTime).seconds
                val km = aggregate?.get(DistanceRecord.DISTANCE_TOTAL)?.inKilometers
                val calories = aggregate?.get(TotalCaloriesBurnedRecord.ENERGY_TOTAL)?.inKilocalories
                val avgHeartRate = aggregate?.get(HeartRateRecord.BPM_AVG)
                val maxHeartRate = aggregate?.get(HeartRateRecord.BPM_MAX)
                val avgSpeed = aggregate?.get(SpeedRecord.SPEED_AVG)?.inKilometersPerHour
                val maxSpeed = aggregate?.get(SpeedRecord.SPEED_MAX)?.inKilometersPerHour
                val avgCadence = aggregate?.get(StepsCadenceRecord.RATE_AVG)
                val maxCadence = aggregate?.get(StepsCadenceRecord.RATE_MAX)
                val elevation = aggregate?.get(ElevationGainedRecord.ELEVATION_GAINED_TOTAL)?.inMeters
                val localDate = session.startTime.atZone(ZoneId.systemDefault()).toLocalDate()
                val standardTypeName = when (session.exerciseType) {
                    ExerciseSessionRecord.EXERCISE_TYPE_BADMINTON -> "배드민턴"
                    ExerciseSessionRecord.EXERCISE_TYPE_BASEBALL -> "야구"
                    ExerciseSessionRecord.EXERCISE_TYPE_BASKETBALL -> "농구"
                    ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "야외 달리기"
                    ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "러닝머신"
                    ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "등산"
                    ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "걷기"
                    ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "야외 자전거"
                    ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY -> "실내 자전거"
                    ExerciseSessionRecord.EXERCISE_TYPE_BOXING -> "복싱"
                    ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "근력운동"
                    ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING -> "웨이트트레이닝"
                    ExerciseSessionRecord.EXERCISE_TYPE_CALISTHENICS -> "맨몸 근력운동"
                    ExerciseSessionRecord.EXERCISE_TYPE_BOOT_CAMP -> "부트캠프"
                    ExerciseSessionRecord.EXERCISE_TYPE_EXERCISE_CLASS -> "운동 수업"
                    ExerciseSessionRecord.EXERCISE_TYPE_DANCING -> "댄스"
                    ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "일립티컬"
                    ExerciseSessionRecord.EXERCISE_TYPE_GOLF -> "골프"
                    ExerciseSessionRecord.EXERCISE_TYPE_GYMNASTICS -> "체조"
                    ExerciseSessionRecord.EXERCISE_TYPE_HIGH_INTENSITY_INTERVAL_TRAINING -> "고강도 인터벌 트레이닝"
                    ExerciseSessionRecord.EXERCISE_TYPE_MARTIAL_ARTS -> "무술"
                    ExerciseSessionRecord.EXERCISE_TYPE_PILATES -> "필라테스"
                    ExerciseSessionRecord.EXERCISE_TYPE_ROCK_CLIMBING -> "암벽 등반"
                    ExerciseSessionRecord.EXERCISE_TYPE_ROWING -> "야외 조정"
                    ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE -> "로잉 머신"
                    ExerciseSessionRecord.EXERCISE_TYPE_SOCCER -> "축구"
                    ExerciseSessionRecord.EXERCISE_TYPE_STAIR_CLIMBING -> "계단 오르기"
                    ExerciseSessionRecord.EXERCISE_TYPE_STAIR_CLIMBING_MACHINE -> "스텝 머신"
                    ExerciseSessionRecord.EXERCISE_TYPE_STRETCHING -> "스트레칭"
                    ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "야외 수영"
                    ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL -> "수영장 수영"
                    ExerciseSessionRecord.EXERCISE_TYPE_TABLE_TENNIS -> "탁구"
                    ExerciseSessionRecord.EXERCISE_TYPE_TENNIS -> "테니스"
                    ExerciseSessionRecord.EXERCISE_TYPE_VOLLEYBALL -> "배구"
                    ExerciseSessionRecord.EXERCISE_TYPE_YOGA -> "요가"
                    ExerciseSessionRecord.EXERCISE_TYPE_OTHER_WORKOUT -> "일반 운동"
                    else -> "일반 운동"
                }
                val typeName = session.title?.trim()?.takeIf { it.isNotEmpty() }
                    ?: session.notes?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 }
                    ?: standardTypeName
                rows.put(JSONObject().apply {
                    put("id", session.metadata.id)
                    put("date", localDate.format(DateTimeFormatter.ISO_LOCAL_DATE))
                    put("startTime", session.startTime.toString())
                    put("endTime", session.endTime.toString())
                    put("minutes", durationSeconds / 60)
                    put("durationSeconds", durationSeconds)
                    put("distance", km?.let { round(it * 100.0) / 100.0 } ?: JSONObject.NULL)
                    put("paceSeconds", if (km != null && km > 0) (durationSeconds / km).toInt() else 0)
                    put("avgHeartRate", avgHeartRate ?: JSONObject.NULL)
                    put("maxHeartRate", maxHeartRate ?: JSONObject.NULL)
                    put("avgSpeedKmh", avgSpeed ?: JSONObject.NULL)
                    put("maxSpeedKmh", maxSpeed ?: JSONObject.NULL)
                    put("avgCadence", avgCadence ?: JSONObject.NULL)
                    put("maxCadence", maxCadence ?: JSONObject.NULL)
                    put("elevationMeters", elevation ?: JSONObject.NULL)
                    put("calories", calories?.toInt() ?: JSONObject.NULL)
                    put("type", typeName)
                    put("sourcePackage", session.metadata.dataOrigin.packageName)
                    put("sourceName", sourceName(session.metadata.dataOrigin.packageName))
                    put("metricsStatus", aggregateStatus)
                    put("isRunning", session.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING || session.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL)
                    put("isStrength", session.exerciseType in setOf(
                        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
                        ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING,
                        ExerciseSessionRecord.EXERCISE_TYPE_CALISTHENICS,
                        ExerciseSessionRecord.EXERCISE_TYPE_BOOT_CAMP,
                        ExerciseSessionRecord.EXERCISE_TYPE_EXERCISE_CLASS,
                        ExerciseSessionRecord.EXERCISE_TYPE_OTHER_WORKOUT
                    ))
                })
            }
            payload.put("activities", rows)
            payload.put("activitiesStatus", "ok")
            payload.put("activitiesReadDays", window.days)
            payload.put("activitiesRangeStart", window.start.toString())
            payload.put("activitiesRangeEnd", end.toString())
            payload.put("activitiesHistoryFallback", window.historyFallback)
            payload.put("activityAggregateErrors", aggregateErrors)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            payload.put("activitiesStatus", if (e is SecurityException) "permission_denied" else "error")
            payload.put("activitiesErrorCode", e.javaClass.simpleName)
        }
    }

    private suspend fun syncHealth(client: HealthConnectClient, granted: Set<String>) {
        sendStatus("Health Connect 기록을 확인하는 중입니다", granted.any { it in permissions }, busy = true)
        val readAt = Instant.now()
        val payload = JSONObject().apply {
            put("readAt", readAt.toString())
            put("syncStartedAt", readAt.toString())
            put("grantedReadPermissions", JSONArray(granted.filter { it in permissions }))
            put("missingReadPermissions", JSONArray(permissions.filter { it !in granted }))
        }
        // Read wellness independently; an exercise/aggregate error cannot cancel these results.
        payload.put("wellness", readWellness(client, granted, readAt))
        readActivities(client, granted, readAt, payload)
        payload.put("syncedAt", Instant.now().toString())
        if (!foreground || !pageReady) return
        webView.evaluateJavascript("if (typeof window.receiveSamsungHealthData === 'function') window.receiveSamsungHealthData($payload);", null)
        val grantedAny = granted.any { it in permissions }
        val metricStatuses = payload.getJSONObject("wellness").getJSONObject("meta").let { meta ->
            meta.keys().asSequence().map { meta.getJSONObject(it).optString("status") }.toList()
        }
        val hasErrors = payload.optString("activitiesStatus") == "error" ||
            payload.optInt("activityAggregateErrors", 0) > 0 || "error" in metricStatuses
        val permissionMissing = !granted.containsAll(permissions) ||
            payload.optString("activitiesStatus") == "permission_denied" || "permission_denied" in metricStatuses
        val message = when {
            !grantedAny -> "Health Connect 읽기 권한을 허용해 주세요"
            hasErrors -> "기록 확인 중 일부 항목을 불러오지 못했습니다"
            permissionMissing -> "허용된 항목만 확인했습니다 · 항목별 측정일을 확인해 주세요"
            else -> "기록 확인 완료 · 항목별 측정일을 확인해 주세요"
        }
        sendStatus(message, grantedAny)
    }

    private fun sendStatus(message: String, connected: Boolean, busy: Boolean = false) {
        if (!::webView.isInitialized || !pageReady || !foreground) return
        val payload = JSONObject().apply {
            put("message", message)
            put("connected", connected)
            put("busy", busy)
        }
        webView.post {
            if (pageReady && foreground) webView.evaluateJavascript("if (typeof window.receiveHealthStatus === 'function') window.receiveHealthStatus($payload);", null)
        }
    }
}
