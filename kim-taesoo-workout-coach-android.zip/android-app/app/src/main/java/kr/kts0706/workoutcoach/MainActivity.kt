package kr.kts0706.workoutcoach

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var healthClient: HealthConnectClient? = null

    private val permissions = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class)
    )

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (granted.containsAll(permissions)) syncRuns() else sendStatus("권한이 허용되지 않았습니다", false)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(HealthBridge(), "AndroidHealth")
        webView.loadUrl("file:///android_asset/index.html")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                connectAndSync(false)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) connectAndSync(false)
    }

    inner class HealthBridge {
        @JavascriptInterface fun connect() = runOnUiThread { connectAndSync(true) }
        @JavascriptInterface fun sync() = runOnUiThread { connectAndSync(false) }
        @JavascriptInterface fun isNativeApp(): Boolean = true
    }

    private fun connectAndSync(requestIfMissing: Boolean) {
        val status = HealthConnectClient.getSdkStatus(this)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            sendStatus("Health Connect를 사용할 수 없습니다", false)
            return
        }
        healthClient = HealthConnectClient.getOrCreate(this)
        lifecycleScope.launch {
            val granted = healthClient!!.permissionController.getGrantedPermissions()
            if (granted.containsAll(permissions)) syncRuns()
            else if (requestIfMissing) permissionLauncher.launch(permissions)
            else sendStatus("삼성헬스 연결이 필요합니다", false)
        }
    }

    private fun syncRuns() {
        val client = healthClient ?: return
        lifecycleScope.launch {
            try {
                sendStatus("삼성헬스 기록을 불러오는 중입니다", true)
                val end = Instant.now()
                val start = end.minus(Duration.ofDays(31))
                val sessions = client.readRecords(
                    ReadRecordsRequest(
                        ExerciseSessionRecord::class,
                        TimeRangeFilter.between(start, end),
                        ascendingOrder = false
                    )
                ).records.filter {
                    it.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING ||
                    it.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL
                }

                val rows = JSONArray()
                for (session in sessions) {
                    val filter = TimeRangeFilter.between(session.startTime, session.endTime)
                    val aggregate = client.aggregate(
                        AggregateRequest(
                            setOf(
                                DistanceRecord.DISTANCE_TOTAL,
                                TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                                HeartRateRecord.BPM_AVG
                            ),
                            filter
                        )
                    )
                    val minutes = Duration.between(session.startTime, session.endTime).toMinutes()
                    val km = aggregate[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0
                    val calories = aggregate[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0
                    val avgHeartRate = aggregate[HeartRateRecord.BPM_AVG]
                    val localDate = session.startTime.atZone(ZoneId.systemDefault()).toLocalDate()
                    rows.put(JSONObject().apply {
                        put("id", session.metadata.id)
                        put("date", localDate.format(DateTimeFormatter.ISO_LOCAL_DATE))
                        put("startTime", session.startTime.toString())
                        put("minutes", minutes)
                        put("distance", String.format("%.2f", km).toDouble())
                        put("paceSeconds", if (km > 0) (minutes * 60 / km).toInt() else 0)
                        put("avgHeartRate", avgHeartRate ?: JSONObject.NULL)
                        put("calories", calories.toInt())
                        put("type", if (session.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL) "러닝머신" else "야외 달리기")
                    })
                }
                val payload = JSONObject().apply {
                    put("syncedAt", Instant.now().toString())
                    put("runs", rows)
                }
                webView.evaluateJavascript("window.receiveSamsungHealthData(${payload});", null)
                sendStatus("삼성헬스 동기화 완료 · ${sessions.size}회", true)
            } catch (e: Exception) {
                sendStatus("동기화 중 문제가 발생했습니다", false)
            }
        }
    }

    private fun sendStatus(message: String, connected: Boolean) {
        if (!::webView.isInitialized) return
        val payload = JSONObject().apply {
            put("message", message)
            put("connected", connected)
        }
        webView.post { webView.evaluateJavascript("window.receiveHealthStatus(${payload});", null) }
    }
}
