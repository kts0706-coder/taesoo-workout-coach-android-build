package kr.kts0706.workoutcoach

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.BodyFatRecord
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.records.ElevationGainedRecord
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.StepsCadenceRecord
import androidx.health.connect.client.records.Vo2MaxRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var healthClient: HealthConnectClient? = null

    private val permissions = setOf(
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(StepsCadenceRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class)
    )

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        if (granted.containsAll(permissions)) syncRuns() else sendStatus("권한이 허용되지 않았습니다", false)
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(HealthBridge(), "AndroidHealth")
        webView.loadUrl("file:///android_asset/index.html")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                connectAndSync(false)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) connectAndSync(false)
    }

    inner class HealthBridge {
        @JavascriptInterface fun connect() = runOnUiThread { connectAndSync(true) }
        @JavascriptInterface fun sync() = runOnUiThread { connectAndSync(false) }
        @JavascriptInterface fun isNativeApp(): Boolean = true
    }

    private fun connectAndSync(requestIfMissing: Boolean) {
        val status = HealthConnectClient.getSdkStatus(this)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            sendStatus("Health Connect를 사용할 수 없습니다", false)
            return
        }
        healthClient = HealthConnectClient.getOrCreate(this)
        lifecycleScope.launch {
            val granted = healthClient!!.permissionController.getGrantedPermissions()
            if (granted.containsAll(permissions)) syncRuns()
            else if (requestIfMissing) permissionLauncher.launch(permissions)
            else sendStatus("삼성헬스 연결이 필요합니다", false)
        }
    }

    private fun syncRuns() {
        val client = healthClient ?: return
        lifecycleScope.launch {
            try {
                sendStatus("삼성헬스 기록을 불러오는 중입니다", true)
                val end = Instant.now()
                val start = end.minus(Duration.ofDays(365))
                val sessions = client.readRecords(
                    ReadRecordsRequest(
                        ExerciseSessionRecord::class,
                        TimeRangeFilter.between(start, end),
                        ascendingOrder = false
                    )
                ).records.filter { session ->
                    session.exerciseType in setOf(
                        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING,
                        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL,
                        ExerciseSessionRecord.EXERCISE_TYPE_HIKING,
                        ExerciseSessionRecord.EXERCISE_TYPE_WALKING,
                        ExerciseSessionRecord.EXERCISE_TYPE_BIKING,
                        ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY,
                        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING,
                        ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING
                    )
                }

                val rows = JSONArray()
                for (session in sessions) {
                    val filter = TimeRangeFilter.between(session.startTime, session.endTime)
                    val aggregate = client.aggregate(
                        AggregateRequest(
                            setOf(
                                DistanceRecord.DISTANCE_TOTAL,
                                TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                                HeartRateRecord.BPM_AVG,
                                HeartRateRecord.BPM_MAX,
                                SpeedRecord.SPEED_AVG,
                                SpeedRecord.SPEED_MAX,
                                StepsCadenceRecord.RATE_AVG,
                                StepsCadenceRecord.RATE_MAX,
                                ElevationGainedRecord.ELEVATION_GAINED_TOTAL
                            ),
                            filter
                        )
                    )
                    val durationSeconds = Duration.between(session.startTime, session.endTime).seconds
                    val minutes = durationSeconds / 60
                    val km = aggregate[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0
                    val calories = aggregate[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0
                    val avgHeartRate = aggregate[HeartRateRecord.BPM_AVG]
                    val maxHeartRate = aggregate[HeartRateRecord.BPM_MAX]
                    val avgSpeed = aggregate[SpeedRecord.SPEED_AVG]?.inKilometersPerHour
                    val maxSpeed = aggregate[SpeedRecord.SPEED_MAX]?.inKilometersPerHour
                    val avgCadence = aggregate[StepsCadenceRecord.RATE_AVG]
                    val maxCadence = aggregate[StepsCadenceRecord.RATE_MAX]
                    val elevation = aggregate[ElevationGainedRecord.ELEVATION_GAINED_TOTAL]?.inMeters
                    val localDate = session.startTime.atZone(ZoneId.systemDefault()).toLocalDate()
                    val typeName = when (session.exerciseType) {
                        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "야외 달리기"
                        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "러닝머신"
                        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "등산"
                        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "걷기"
                        ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "야외 자전거"
                        ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY -> "실내 자전거"
                        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "근력운동"
                        ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING -> "웨이트트레이닝"
                        else -> "기타 운동"
                    }
                    rows.put(JSONObject().apply {
                        put("id", session.metadata.id)
                        put("date", localDate.format(DateTimeFormatter.ISO_LOCAL_DATE))
                        put("startTime", session.startTime.toString())
                        put("minutes", minutes)
                        put("durationSeconds", durationSeconds)
                        put("distance", String.format("%.2f", km).toDouble())
                        put("paceSeconds", if (km > 0) (durationSeconds / km).toInt() else 0)
                        put("avgHeartRate", avgHeartRate ?: JSONObject.NULL)
                        put("maxHeartRate", maxHeartRate ?: JSONObject.NULL)
                        put("avgSpeedKmh", avgSpeed ?: JSONObject.NULL)
                        put("maxSpeedKmh", maxSpeed ?: JSONObject.NULL)
                        put("avgCadence", avgCadence ?: JSONObject.NULL)
                        put("maxCadence", maxCadence ?: JSONObject.NULL)
                        put("elevationMeters", elevation ?: JSONObject.NULL)
                        put("calories", calories.toInt())
                        put("type", typeName)
                        put("isRunning", session.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING || session.exerciseType == ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL)
                    })
                }

                val latestWeight = client.readRecords(
                    ReadRecordsRequest(WeightRecord::class, TimeRangeFilter.between(start, end), ascendingOrder = false, pageSize = 1)
                ).records.firstOrNull()
                val latestBodyFat = client.readRecords(
                    ReadRecordsRequest(BodyFatRecord::class, TimeRangeFilter.between(start, end), ascendingOrder = false, pageSize = 1)
                ).records.firstOrNull()
                val latestRestingHeartRate = client.readRecords(
                    ReadRecordsRequest(RestingHeartRateRecord::class, TimeRangeFilter.between(start, end), ascendingOrder = false, pageSize = 1)
                ).records.firstOrNull()
                val latestVo2Max = client.readRecords(
                    ReadRecordsRequest(Vo2MaxRecord::class, TimeRangeFilter.between(start, end), ascendingOrder = false, pageSize = 1)
                ).records.firstOrNull()

                val todayStart = java.time.LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
                val stepsToday = client.aggregate(
                    AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), TimeRangeFilter.between(todayStart, end))
                )[StepsRecord.COUNT_TOTAL] ?: 0L

                val sleepStart = end.minus(Duration.ofDays(7))
                val latestSleep = client.readRecords(
                    ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(sleepStart, end), ascendingOrder = false, pageSize = 1)
                ).records.firstOrNull()
                val sleepMinutes = latestSleep?.let { Duration.between(it.startTime, it.endTime).toMinutes() }

                val wellness = JSONObject().apply {
                    put("weightKg", latestWeight?.weight?.inKilograms ?: JSONObject.NULL)
                    put("bodyFatPercent", latestBodyFat?.percentage?.value ?: JSONObject.NULL)
                    put("stepsToday", stepsToday)
                    put("sleepMinutes", sleepMinutes ?: JSONObject.NULL)
                    put("restingHeartRate", latestRestingHeartRate?.beatsPerMinute ?: JSONObject.NULL)
                    put("vo2Max", latestVo2Max?.vo2MillilitersPerMinuteKilogram ?: JSONObject.NULL)
                }
                val payload = JSONObject().apply {
                    put("syncedAt", Instant.now().toString())
                    put("activities", rows)
                    put("wellness", wellness)
                }
                webView.evaluateJavascript("window.receiveSamsungHealthData(${payload});", null)
                sendStatus("삼성헬스 동기화 완료 · 운동 ${sessions.size}회", true)
            } catch (e: Exception) {
                sendStatus("동기화 중 문제가 발생했습니다", false)
            }
        }
    }

    private fun sendStatus(message: String, connected: Boolean) {
        if (!::webView.isInitialized) return
        val payload = JSONObject().apply {
            put("message", message)
            put("connected", connected)
        }
        webView.post { webView.evaluateJavascript("window.receiveHealthStatus(${payload});", null) }
    }
}
