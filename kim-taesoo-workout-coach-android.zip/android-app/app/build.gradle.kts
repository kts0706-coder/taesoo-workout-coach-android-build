plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "kr.kts0706.workoutcoach"
    compileSdk = 36

    defaultConfig {
        applicationId = "kr.kts0706.workoutcoach"
        minSdk = 28
        targetSdk = 35
        versionCode = 6
        versionName = "1.6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures { buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("stable-debug.keystore")
            storePassword = "taesoo2026"
            keyAlias = "workoutcoach"
            keyPassword = "taesoo2026"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("stableDebug") }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.health.connect:connect-client:1.1.0")
}
