# 김태수 운동 코치 Android

기존 근력운동 화면을 그대로 포함하고 Health Connect를 통해 삼성헬스 러닝 기록을 읽는 Android 앱입니다.

- 앱을 열 때마다 최근 31일 러닝 자동 동기화
- 운동 세션, 거리, 시간, 평균 심박수, 소모 열량 읽기
- 최초 1회 Health Connect 권한 승인 필요
- 삼성헬스에서 Health Connect로 운동 데이터 공유가 켜져 있어야 함

Android Studio에서 프로젝트를 열어 `app`을 실행하거나 서명된 APK를 빌드합니다.
