// Regression check for activity switching and Home/running-stretch records.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../android-app/app/src/main/assets/index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(js); // Parse the complete app before testing focused functions.
// Evaluate the real declarations and migration layer, rather than slicing one
// data block whose end can move when a plan version is introduced.
const bootstrap = js.indexOf("  document.querySelectorAll('.view-btn')");
assert.ok(bootstrap > 0, 'Expected app bootstrap after its declarations');
const context = vm.createContext({
  assert, document: {querySelector: () => ({})},
  localStorage: {getItem: () => null}, window: {}
});
vm.runInContext(js.slice(0, bootstrap), context);
vm.runInContext(`
let state={date:'2026-09-23',day:2,selectedActivity:'home',exercises:[{done:true}],run:{}};
let saves=0;focus=0;expandedExercise=0;day=2;
getRecord=()=>JSON.parse(JSON.stringify(state));
saveRecord=r=>{state=JSON.parse(JSON.stringify(r));saves++};
render=()=>{};show=()=>{};
selectedDate=()=>state.date;
healthOn=()=>[];allRecords=()=>[state];
chooseActivity('home');
assert.equal(saves,0,'same Home button must not save/reset');
assert.equal(state.exercises[0].done,true);
chooseActivity('strength');
assert.equal(state.exercises.length,0,'new strength must not inherit home checks');
state.selectedSplit='legs';state.exercises=[{done:true,sets:[{weight:30,reps:12}]}];
chooseActivity('home');
assert.equal(state.exercises[0].done,true,'Home check restored');
assert.equal(state.exercises[0].sets,undefined,'Home has no strength sets');
assert.equal(recordPlan(state).ex[0][0],'캣카우 전신 스트레칭');
chooseActivity('strength');
assert.equal(state.exercises[0].sets[0].weight,30,'strength sets restored');
assert.equal(recordValues(state).home,1);
assert.equal(recordValues(state).manualStrength,1,'active slot must not double-count');
let details=detailForDate(state.date);
assert.ok(details.includes('캣카우 전신 스트레칭'),'Home names present after switching');
assert.ok(details.includes('레그 프레스'),'strength names present');
chooseActivity('runstretch');
state.primaryActivity={type:'runstretch',label:'러닝 스트레칭',minutes:'10',done:true};
assert.equal(hasRunningRecord(state),false,'stretching is not running');
details=detailForDate(state.date);
assert.ok(details.includes('러닝 스트레칭'));
assert.ok(details.includes('10분 · 완료'));
chooseActivity('running');
state.primaryActivity={type:'running',label:'러닝',distance:'3',minutes:'25',done:true};
chooseActivity('home');
assert.equal(hasRunningRecord(state),true);
assert.equal(recordValues(state).km,3);
assert.ok(detailForDate(state.date).includes('러닝 스트레칭'),'saved stretch still in history');
assert.ok(exerciseTargetHtml('푸시업').includes('대흉근'));
assert.ok(homeWorkoutPlan.ex.every(e=>exerciseTargetHtml(e[0])),'all Home movements have target labels');
`, context);
console.log('PASS: complete JavaScript syntax, no-op selection, activity restoration, history labels/details, running progress and Home targets');
