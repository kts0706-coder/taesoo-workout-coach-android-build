// Exercise-plan upgrades must not rename or discard existing workout records.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '../android-app/app/src/main/assets/index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(js);
const bootstrap = js.indexOf("  document.querySelectorAll('.view-btn')");
assert.ok(bootstrap > 0, 'Expected the app bootstrap after its declarations');
const storage = Object.create(null);
Object.defineProperties(storage, {
  getItem: {value: key => storage[key] ?? null},
  setItem: {value: (key, value) => { storage[key] = String(value); }},
  removeItem: {value: key => { delete storage[key]; }}
});
const context = vm.createContext({
  assert, console, localStorage: storage, window: {},
  document: {querySelector: () => ({})},
  confirm: () => true
});
vm.runInContext(js.slice(0, bootstrap), context);
vm.runInContext(`
const testDate='2026-09-23';
selectedDate=()=>testDate;day=2;render=()=>{};show=()=>{};
const seed=r=>localStorage.setItem(journalKey(testDate),JSON.stringify({date:testDate,day:2,...r}));
const names=p=>p.ex.map(e=>e[0]);
const forbidden=/버드독|데드버그/;
const assertFullCore=(p,label)=>{
  assert.ok(!names(p).some(n=>forbidden.test(n)),label+' must exclude the retired exercises');
  const targets=p.ex.map(e=>exerciseTargetHtml(e[0])).join(' ');
  assert.ok(targets.includes('상복부'),label+' needs an upper emphasis');
  assert.ok(targets.includes('하복부'),label+' needs a lower emphasis');
  assert.ok(/옆구리|복사근/.test(targets),label+' needs an oblique movement');
  assert.equal(new Set(names(p)).size,p.ex.length,label+' should not duplicate movements');
};
assert.equal(Object.values(splitPrograms).flat().length,6);
Object.entries(splitPrograms).forEach(([part,variants])=>variants.forEach((p,i)=>assertFullCore(p,part+i)));
assertFullCore(homeWorkoutPlan,'Home');
for(let d=0;d<7;d++){
  const p=planFor('2026-09-23',d);
  if(p.ex.length)assertFullCore(p,'legacy weekday replacement '+d);
}
for(let w=0;w<5;w++)for(let d=0;d<7;d++){
  const p=planFor('2026-10-'+String(1+w*7).padStart(2,'0'),d);
  if(p.ex.length)assertFullCore(p,'October '+w+':'+d);
}

// The oldest app stored a single weight/reps pair rather than a sets array.
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,exercises:[{weight:'12',reps:'10'}]});
let old=getRecord();
assert.notEqual(old.corePlanVersion,2,'single-row legacy records must not be silently upgraded');
assert.ok(names(recordPlan(old)).includes('데드버그'),'old recorded exercise identities stay readable');
assert.equal(old.exercises[0].weight,'12');
assert.equal(old.exercises[0].reps,'10');

// A modern current activity must not lend its version to a legacy saved slot.
seed({selectedActivity:'cycling',corePlanVersion:2,exercises:[],activityRecords:{
  home:{exercises:[{done:true}],primaryActivity:{}}
}});
let inactive=workoutRecords(getRecord()).find(r=>selectedActivity(r)==='home');
assert.notEqual(inactive.corePlanVersion,2,'inactive legacy Home slot must keep its legacy version');
assert.ok(names(recordPlan(inactive)).includes('데드버그'));
chooseActivity('home');
old=getRecord();
assert.notEqual(old.corePlanVersion,2,'restoring a legacy slot must not inherit current version');
assert.ok(names(recordPlan(old)).includes('데드버그'));
assert.equal(old.exercises[0].done,true,'restoring a slot preserves completion');

// Explicit saved names win over a subsequently edited template.
const historicalExercises=[['기록 당시 운동','2세트 × 10회','1_1.jpg','방법',['설명']]];
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:0,corePlanVersion:2,
  exercises:[{done:true,sets:[{weight:'9',reps:'11'}]}],
  planExercises:historicalExercises,planMeta:{title:'기록 당시 구성',meta:'기록 당시 설명'},
  assignedPlan:{title:'기록 당시 구성',category:'가슴',total:1}
});
assert.equal(recordPlan(getRecord()).ex[0][0],'기록 당시 운동','saved names override current templates');
saveRecord(getRecord());
assert.equal(getRecord().planExercises[0][0],'기록 당시 운동','unrelated saves preserve the original snapshot');
chooseActivity('home');
const savedStrength=workoutRecords(getRecord()).find(r=>selectedActivity(r)==='strength');
assert.equal(recordPlan(savedStrength).ex[0][0],'기록 당시 운동','inactive snapshot preserves names');
assert.equal(savedStrength.exercises[0].sets[0].weight,'9');
chooseActivity('strength');
assert.equal(recordPlan(getRecord()).ex[0][0],'기록 당시 운동','snapshot survives an activity round trip');
assert.equal(getRecord().exercises[0].sets[0].reps,'11');

// Every newly assigned movement retains the existing tap-to-view interaction.
Object.values(absExercises).forEach((e,i)=>{
  assert.ok(exerciseDetail(e,{},i).includes('data-photo'),'new abs movement needs tappable step images: '+e[0]);
});
assert.ok(exerciseDetail(lowerChestFly,{},0).includes('data-photo'),'new chest fly needs tappable step images');
const timedHtml=exerciseDetail(absExercises.side,{sets:[{secondsLeft:'25',secondsRight:'24'}]},0);
assert.ok(timedHtml.includes('왼쪽 초')&&timedHtml.includes('오른쪽 초'),'side planks record each side in seconds');
assert.ok(setText({sets:[{secondsLeft:'25',secondsRight:'24'}]}).includes('왼쪽 25초 · 오른쪽 24초'),'history preserves hold units');
seed({selectedActivity:'strength',selectedSplit:'chest',splitVariant:1,corePlanVersion:2,exercises:[]});
saveSetInput({dataset:{setEx:'7',setN:'0',setK:'secondsLeft'},value:'25'},false);
assert.equal(getRecord().exercises[7].sets[0].secondsLeft,'25');
assert.ok(hasExerciseData(getRecord()),'time-only entries count as saved data');
for(const e of Object.values(absExercises))for(let n=0;n<4;n++){
 assert.ok(exercisePhotoMarkup(e[2],e[0],n,true).includes('data-zoom-photo'),'step viewer binds zoom for every new pose');
}

`, context);
console.log('PASS: active core coverage, legacy identity, saved snapshots, activity restoration and photo entry points');
